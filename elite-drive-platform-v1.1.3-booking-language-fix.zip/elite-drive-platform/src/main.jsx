import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  useNavigate,
} from "react-router-dom";
import { createClient } from "@supabase/supabase-js";
import {
  LayoutDashboard,
  CarFront,
  CalendarDays,
  Users,
  Wallet,
  Landmark,
  Wrench,
  PanelsTopLeft,
  BarChart3,
  Settings,
  Search,
  Bell,
  Plus,
  Menu,
  X,
  ArrowUpLeft,
  ArrowDownLeft,
  TrendingUp,
  CircleDollarSign,
  Clock3,
  CheckCircle2,
  AlertTriangle,
  Fuel,
  Gauge,
  ChevronLeft,
  Eye,
  Pencil,
  Trash2,
  LogOut,
  Globe,
  ShieldCheck,
  Database,
  Download,
  FileText,
  Image,
  Phone,
  MapPin,
  CreditCard,
  Activity,
} from "lucide-react";
import {
  APP_VERSION,
  SCHEMA_VERSION,
  normalizeSettings,
  normalizePhone,
  buildBookingPricing,
  buildMonthlyFinancials,
  updateSiteSettings,
  getBrandLogos,
  saveBrandLogos,
  uploadOptimizedSiteAsset,
  buildOperationalBackup,
  fetchBackupSnapshot,
  restoreBackupSnapshot,
  recordAudit,
} from "./platform.js";
import "./styles.css";

const url = import.meta.env.VITE_SUPABASE_URL,
  key = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = url && key ? createClient(url, key) : null;

// Always prefer a canonical Supabase Storage URL when a stored asset path exists.
// Older logo records may have a stale URL but a valid Storage path.
function normalizeBrandLogo(logo, client = supabase) {
  if (!logo || typeof logo !== "object") return null;
  let url = String(logo.url || "").trim();
  const path = String(logo.path || "").trim();
  if (path && client && !/^https?:\/\//i.test(path)) {
    const canonical = client.storage.from("site-assets").getPublicUrl(path).data?.publicUrl;
    if (canonical) url = canonical;
  } else if (!url && /^https?:\/\//i.test(path)) {
    url = path;
  }
  return { ...logo, url };
}
const demoCars = [
  {
    id: "demo-car-1",
    name: "Dacia Logan",
    plate: "DEMO-001",
    category: "اقتصادية",
    daily_rate: 250,
    status: "available",
    year: 2023,
    km: 42000,
    image_url:
      "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=900&q=80",
    purchase_price: 125000,
  },
  {
    id: "demo-car-2",
    name: "Dacia Duster",
    plate: "DEMO-002",
    category: "SUV",
    daily_rate: 350,
    status: "rented",
    year: 2024,
    km: 18000,
    image_url:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=900&q=80",
    purchase_price: 210000,
  },
  {
    id: "demo-car-3",
    name: "Renault Clio",
    plate: "DEMO-003",
    category: "مدمجة",
    daily_rate: 280,
    status: "maintenance",
    year: 2022,
    km: 61000,
    image_url:
      "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=900&q=80",
    purchase_price: 145000,
  },
];
const demoBookings = [
  {
    id: "demo-book-1",
    customer_name: "عميل تجريبي 01",
    car_name: "Dacia Duster",
    start_date: "2026-10-21",
    end_date: "2026-10-24",
    total_amount: 1050,
    paid_amount: 500,
    status: "active",
  },
  {
    id: "demo-book-2",
    customer_name: "عميل تجريبي 02",
    car_name: "Dacia Logan",
    start_date: "2026-10-23",
    end_date: "2026-10-25",
    total_amount: 500,
    paid_amount: 0,
    status: "pending",
  },
  {
    id: "demo-book-3",
    customer_name: "عميل تجريبي 03",
    car_name: "Renault Clio",
    start_date: "2026-10-18",
    end_date: "2026-10-20",
    total_amount: 560,
    paid_amount: 560,
    status: "completed",
  },
];
const demoExpenses = [
  {
    id: "demo-exp-1",
    title: "صيانة دورية - مثال",
    category: "maintenance",
    amount: 450,
    date: "2026-10-18",
    car_name: "Renault Clio",
  },
  {
    id: "demo-exp-2",
    title: "تأمين - مثال توضيحي",
    category: "insurance",
    amount: 700,
    date: "2026-10-10",
    car_name: "Dacia Logan",
  },
];
const money = (n) =>
  new Intl.NumberFormat("fr-MA", {
    style: "currency",
    currency: "MAD",
    maximumFractionDigits: 0,
  })
    .format(Number(n || 0))
    .replace("MAD", "د.م.");
const dateLabel = (s) =>
  s
    ? new Date(s + "T12:00:00").toLocaleDateString("ar-MA", {
        day: "numeric",
        month: "short",
        year: "numeric",
      })
    : "—";
const statusMap = {
  available: ["متاحة", "green"],
  rented: ["مكتراة", "blue"],
  maintenance: ["في الصيانة", "orange"],
  unavailable: ["غير متاحة", "red"],
  pending: ["في الانتظار", "orange"],
  confirmed: ["مؤكد", "blue"],
  active: ["جارية", "green"],
  completed: ["مكتملة", "gray"],
  cancelled: ["ملغاة", "red"],
  paid: ["مؤدى", "green"],
  overdue: ["متأخر", "red"],
};
const defaultSiteSettings = normalizeSettings();
const operationalDefaults = {
  cars: [],
  bookings: [],
  customers: [],
  expenses: [],
  loans: [],
  maintenanceRecords: [],
  payments: [],
};
const liveBookingStatuses = new Set(["pending", "confirmed", "active"]);
const dateRangesOverlap = (aStart, aEnd, bStart, bEnd) => {
  const a = new Date(`${aStart}T00:00:00`);
  const b = new Date(`${aEnd}T00:00:00`);
  const c = new Date(`${bStart}T00:00:00`);
  const d = new Date(`${bEnd}T00:00:00`);
  return a < d && c < b;
};
const nav = [
  ["overview", "لوحة القيادة", LayoutDashboard],
  ["cars", "الأسطول والسيارات", CarFront],
  ["bookings", "الحجوزات والكراء", CalendarDays],
  ["customers", "العملاء", Users],
  ["finance", "المداخيل والمصاريف", Wallet],
  ["loans", "قروض السيارات", Landmark],
  ["maintenance", "الصيانة والوثائق", Wrench],
  ["website", "إدارة صفحة الهبوط", PanelsTopLeft],
  ["reports", "التقارير والتحليلات", BarChart3],
  ["data", "إدارة البيانات", Database],
  ["settings", "الإعدادات والصلاحيات", Settings],
];
function Status({ value }) {
  let [label, color] = statusMap[value] || [value || "غير محدد", "gray"];
  return (
    <span className={"status " + color}>
      <i />
      {label}
    </span>
  );
}
function App() {
  const [section, setSection] = useState("overview"),
    [mobileOpen, setMobileOpen] = useState(false),
    [cars, setCars] = useState(supabase ? operationalDefaults.cars : demoCars),
    [bookings, setBookings] = useState(
      supabase ? operationalDefaults.bookings : demoBookings,
    ),
    [expenses, setExpenses] = useState(
      supabase ? operationalDefaults.expenses : demoExpenses,
    ),
    [maintenanceRecords, setMaintenanceRecords] = useState(
      operationalDefaults.maintenanceRecords,
    ),
    [customers, setCustomers] = useState(operationalDefaults.customers),
    [loans, setLoans] = useState(operationalDefaults.loans),
    [payments, setPayments] = useState(operationalDefaults.payments),
    [logos, setLogos] = useState([]),
    [remote, setRemote] = useState(false),
    [user, setUser] = useState(null),
    [profile, setProfile] = useState(null),
    [authChecked, setAuthChecked] = useState(false),
    [search, setSearch] = useState(""),
    [modal, setModal] = useState(null),
    [toast, setToast] = useState(""),
    [savingEntity, setSavingEntity] = useState(false),
    [sync, setSync] = useState({ at: null, error: "", loading: false });
  const [site, setSite] = useState(defaultSiteSettings);
  async function getAdminProfile(userId) {
    if (!supabase) return { profile: null, error: new Error("Supabase غير مهيأ") };
    const { data, error } = await supabase.rpc("get_my_admin_profile");
    if (error) return { profile: null, error };
    const profile = Array.isArray(data) ? data[0] : data;
    if (!profile || profile.user_id !== userId)
      return { profile: null, error: null };
    return { profile, error: null };
  }
  useEffect(() => {
    if (!supabase) {
      setAuthChecked(true);
      return;
    }
    let alive = true;
    const verify = async (session) => {
      if (!session?.user) {
        if (alive) {
          setUser(null);
          setProfile(null);
          setAuthChecked(true);
        }
        return;
      }
      const { profile, error: profileError } = await getAdminProfile(
        session.user.id,
      );
      const allowed = ["owner", "admin", "manager"];
      if (
        !profileError &&
        profile?.is_active &&
        allowed.includes(profile.role)
      ) {
        if (alive) {
          setUser(session.user);
          setProfile(profile);
          setAuthChecked(true);
          loadRemote();
        }
      } else {
        await supabase.auth.signOut();
        if (alive) {
          setUser(null);
          setAuthChecked(true);
        }
      }
    };
    (async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      await verify(session);
    })();
    const { data: listener } = supabase.auth.onAuthStateChange(
      (_e, session) => {
        setTimeout(() => verify(session), 0);
      },
    );
    return () => {
      alive = false;
      listener.subscription.unsubscribe();
    };
  }, []);
  useEffect(() => {
    if (!supabase || !user) return undefined;
    const refresh = () => loadRemote();
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") refresh();
    });
    const channel = supabase
      .channel("elite-drive-site-sync")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "site_settings", filter: "id=eq.1" },
        refresh,
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "site_sections" },
        refresh,
      )
      .subscribe();
    return () => {
      window.removeEventListener("focus", refresh);
      supabase.removeChannel(channel);
    };
  }, [user]);
  async function loadRemote() {
    if (!supabase) return;
    setSync((p) => ({ ...p, loading: true }));
    const names = [
      "cars",
      "bookings",
      "payments",
      "customers",
      "expenses",
      "vehicle_loans",
      "loan_payments",
      "maintenance_records",
      "site_settings",
      "site_sections",
    ];
    const requests = [
      supabase.from("cars").select("*").order("created_at", { ascending: false }),
      supabase
        .from("bookings")
        .select("*, customers(full_name), cars(name, daily_rate)")
        .order("created_at", { ascending: false }),
      supabase
        .from("payments")
        .select("*, bookings(id, customers(full_name), cars(name))")
        .order("payment_date", { ascending: false })
        .order("created_at", { ascending: false }),
      supabase.from("customers").select("*").order("created_at", { ascending: false }),
      supabase.from("expenses").select("*").order("expense_date", { ascending: false }),
      supabase.from("vehicle_loans").select("*, cars(name)"),
      supabase.from("loan_payments").select("*").order("payment_date", { ascending: false }),
      supabase
        .from("maintenance_records")
        .select("*, cars(name)")
        .order("created_at", { ascending: false }),
      supabase.from("site_settings").select("*").eq("id", 1).maybeSingle(),
      supabase.from("site_sections").select("settings,updated_at").eq("section_key", "brand_logos").maybeSingle(),
    ];
    try {
      const results = await Promise.all(requests);
      const errors = [];
      results.forEach(({ error }, i) => {
        if (error) errors.push(`${names[i]}: ${error.message}`);
      });
      const [c, b, pay, cu, e, l, lp, m, settings, logoSection] = results;
      if (c.data) setCars(c.data);
      if (b.data)
        setBookings(
          (b.data || []).map((x) => ({
            ...x,
            customer_name: x.customers?.full_name || "—",
            car_name: x.cars?.name || "—",
            daily_rate: x.daily_rate ?? x.cars?.daily_rate ?? 0,
          })),
        );
      if (pay.data)
        setPayments(
          (pay.data || []).map((x) => ({
            ...x,
            booking_label: x.bookings?.id
              ? `#${String(x.bookings.id).slice(0, 8)} · ${x.bookings.customers?.full_name || ""}`
              : "—",
          })),
        );
      if (cu.data) setCustomers(cu.data || []);
      if (e.data)
        setExpenses((e.data || []).map((x) => ({ ...x, date: x.expense_date })));
      if (l.data)
        setLoans((l.data || []).map((x) => ({ ...x, car_name: x.cars?.name || "—" })));
      if (lp.data) setLoans((old) => old);
      if (m.data)
        setMaintenanceRecords(
          (m.data || []).map((x) => ({ ...x, car_name: x.cars?.name || "—" })),
        );
      if (settings.data) setSite(normalizeSettings(settings.data));
      if (logoSection.data?.settings?.logos)
        setLogos(
          logoSection.data.settings.logos
            .map((logo) => normalizeBrandLogo(logo))
            .filter((logo) => logo && (logo.url || logo.path || logo.name)),
        );
      const connected = results.some((r) => r.data) && !results.every((r) => r.error);
      setRemote(connected);
      setSync({
        at: new Date(),
        loading: false,
        error: errors.length ? "تعذر تحميل: " + errors.join(" | ") : "",
      });
      if (errors.length) console.error("Supabase partial load errors", errors);
    } catch (error) {
      setRemote(false);
      setSync({ at: new Date(), loading: false, error: error.message || String(error) });
      console.error(error);
    }
  }
  const totals = useMemo(() => {
    const hasPaymentLedger = payments.length > 0;
    const grossPayments = payments
      .filter((p) => p.direction !== "refund")
      .reduce((a, b) => a + Number(b.amount || 0), 0);
    const refunds = payments
      .filter((p) => p.direction === "refund")
      .reduce((a, b) => a + Number(b.amount || 0), 0);
    const legacyBookingCash = bookings.reduce(
      (a, b) => a + Number(b.paid_amount || 0),
      0,
    );
    const revenue = hasPaymentLedger ? grossPayments - refunds : legacyBookingCash;
    const due = bookings.reduce(
      (a, b) =>
        a + Math.max(0, Number(b.total_amount || 0) - Number(b.paid_amount || 0)),
      0,
    );
    const cost = expenses.reduce((a, e) => a + Number(e.amount || 0), 0);
    const monthly = buildMonthlyFinancials(payments, expenses, 7);
    return {
      revenue,
      due,
      cost,
      available: cars.filter((c) => c.status === "available").length,
      rented: cars.filter((c) => c.status === "rented").length,
      maintenance: cars.filter((c) => c.status === "maintenance").length,
      active: bookings.filter((b) => b.status === "active").length,
      net: revenue - cost,
      monthly,
      hasPaymentLedger,
    };
  }, [cars, bookings, expenses, payments]);
  const notify = (t) => {
    setToast(t);
    setTimeout(() => setToast(""), 3200);
  };
  async function signIn(email, password) {
    if (!supabase)
      return "تعذر الاتصال بخدمة تسجيل الدخول. تحقق من إعدادات Supabase.";
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) {
      if (error.message?.toLowerCase().includes("invalid login credentials"))
        return "البريد الإلكتروني أو كلمة المرور غير صحيحة. تحقق من بيانات Authentication → Users أو أعد تعيين كلمة المرور في Supabase.";
      return "تعذر تسجيل الدخول: " + error.message;
    }
    const { profile, error: profileError } = await getAdminProfile(
      data.user.id,
    );
    if (profileError || !profile) {
      await supabase.auth.signOut();
      setUser(null);
      const detail = profileError?.message
        ? ` التفاصيل: ${profileError.message}`
        : "";
      return (
        "تم التحقق من كلمة المرور، لكن تعذرت قراءة صلاحيات المدير عبر get_my_admin_profile. تحقق من تشغيل supabase/fix_admin_profile_rpc.sql ومنح EXECUTE للمستخدم authenticated." +
        detail
      );
    }
    if (
      !profile.is_active ||
      !["owner", "admin", "manager"].includes(profile.role)
    ) {
      await supabase.auth.signOut();
      setUser(null);
      return `الحساب مسجل لكن دوره الحالي هو ${profile.role || "غير محدد"}. نفّذ supabase/fix_admin_profile.sql لتعيين owner للحساب الصحيح.`;
    }
    setUser(data.user);
    setProfile(profile);
    setAuthChecked(true);
    await loadRemote();
    return true;
  }
  async function signOut() {
    await supabase?.auth.signOut();
    setUser(null);
    setProfile(null);
    setRemote(false);
    notify("تم تسجيل الخروج");
  }
  async function saveEntity(type, data) {
    if (savingEntity) return;
    setSavingEntity(true);
    const map = {
      cars: [cars, setCars, "cars"],
      bookings: [bookings, setBookings, "bookings"],
      customers: [customers, setCustomers, "customers"],
      expenses: [expenses, setExpenses, "expenses"],
      loans: [loans, setLoans, "vehicle_loans"],
      maintenance: [
        maintenanceRecords,
        setMaintenanceRecords,
        "maintenance_records",
      ],
    };
    try {
      if (type === "payments") {
        if (!supabase || !remote) throw new Error("سجّل الدخول واتصل بقاعدة البيانات أولاً.");
        const bookingId = data.booking_id;
        const amount = Number(data.amount || 0);
        if (!bookingId || amount <= 0) throw new Error("اختر حجزاً وأدخل مبلغاً صحيحاً أكبر من صفر.");
        const { error } = await supabase.rpc("record_booking_payment", {
          p_booking_id: bookingId,
          p_amount: amount,
          p_method: data.method || "cash",
          p_reference: data.reference || "",
          p_notes: data.notes || "",
          p_payment_date: data.payment_date || new Date().toISOString().slice(0, 10),
        });
        if (error) {
          if (error.message?.includes("record_booking_payment"))
            throw new Error("تعذر تسجيل الدفعة لأن دالة record_booking_payment غير منشأة. نفّذ supabase/upgrade_2026_10_22.sql.");
          throw error;
        }
        await recordAudit(supabase, "payment.recorded", "payments", bookingId, { amount });
        await loadRemote();
        setModal(null);
        notify("تم تسجيل الدفعة وتحديث الرصيد بنجاح");
        return;
      }
      const [items, setItems, table] = map[type] || [];
      if (!table) throw new Error("نوع السجل غير مدعوم.");
      let row = { ...data, id: data.id || crypto.randomUUID() };
      delete row.cars;
      delete row.customers;
      delete row.bookings;
      if (type === "bookings" && row.damage_description !== undefined) {
        const damageText = String(row.damage_description || "").trim();
        if (damageText) row.notes = [String(row.notes || "").trim(), `حالة الأضرار: ${damageText}`].filter(Boolean).join("\\n");
        delete row.damage_description;
      }
      if (type === "expenses" && row.date) {
        row.expense_date = row.date;
        delete row.date;
      }
      if (["expenses", "loans", "maintenance"].includes(type) && row.car_name) {
        const match = cars.find(
          (c) => c.name === row.car_name || String(c.id) === String(row.car_id),
        );
        if (match) row.car_id = match.id;
        delete row.car_name;
      }
      if (type === "customers") {
        row.full_name = String(row.full_name || "").trim();
        row.phone = normalizePhone(row.phone, "");
        if (!row.full_name || !row.phone) throw new Error("اسم العميل ورقم الهاتف مطلوبان.");
        const duplicate = customers.find(
          (c) =>
            c.id !== row.id &&
            c.phone === row.phone &&
            String(c.full_name).toLowerCase() === row.full_name.toLowerCase(),
        );
        if (duplicate) throw new Error("يوجد عميل مسجل بالاسم ورقم الهاتف نفسهما.");
      }
      if (type === "bookings") {
        if (row.customer_name && !row.customer_id) {
          const found = customers.find((c) => c.full_name === row.customer_name);
          if (found) row.customer_id = found.id;
          delete row.customer_name;
        }
        if (row.car_name && !row.car_id) {
          const found = cars.find((c) => c.name === row.car_name);
          if (found) row.car_id = found.id;
          delete row.car_name;
        }
        const pricing = buildBookingPricing(row, cars);
        if (!pricing.customer_id || !pricing.car_id)
          throw new Error("اختر العميل والسيارة من القوائم المسجلة.");
        if (!pricing.start_date || !pricing.end_date || pricing.start_date >= pricing.end_date)
          throw new Error("تاريخ بداية الكراء يجب أن يسبق تاريخ نهايته.");
        if (pricing.total_amount <= 0) throw new Error("المبلغ الإجمالي يجب أن يكون أكبر من صفر.");
        const conflict = bookings.find(
          (b) =>
            b.id !== row.id &&
            b.car_id === pricing.car_id &&
            liveBookingStatuses.has(b.status) &&
            dateRangesOverlap(pricing.start_date, pricing.end_date, b.start_date, b.end_date),
        );
        if (conflict)
          throw new Error(`تتعارض الفترة المحددة مع حجز قائم للسيارة نفسها (${dateLabel(conflict.start_date)} - ${dateLabel(conflict.end_date)}).`);
        row = { ...row, ...pricing };
      }
      if (remote && supabase) {
        const { error } = await supabase.from(table).upsert(row);
        if (error) {
          const hint =
            error.code === "23503"
              ? " تحقق من الارتباط بالسيارة أو العميل، ومن عدم وجود عقود مرتبطة قبل الحذف."
              : error.code === "23P01"
                ? " تعارض الحجز مع فترة قائمة، أعد تحميل البيانات ثم جرّب تواريخ أخرى."
                : "";
          throw new Error(error.message + hint);
        }
        const verify = await supabase.from(table).select("*").eq("id", row.id).maybeSingle();
        if (verify.error || !verify.data)
          throw new Error("تم إرسال الحفظ لكن تعذر استرجاع السجل للتحقق.");
        await recordAudit(supabase, `${type}.upserted`, table, row.id, {
          total_amount: row.total_amount,
        });
        await loadRemote();
      } else {
        setItems((old) =>
          data.id
            ? old.map((x) => (x.id === data.id ? { ...x, ...row } : x))
            : [row, ...old],
        );
        notify("حُفظ محلياً في هذا المتصفح فقط. هذا الوضع للمعاينة وليس حفظاً مركزياً.");
      }
      setModal(null);
    } catch (error) {
      console.error("saveEntity", type, error);
      notify("تعذر الحفظ: " + (error.message || "حدث خطأ غير متوقع"));
    } finally {
      setSavingEntity(false);
    }
  }
  async function removeEntity(type, id) {
    if (!confirm("هل تريد حذف هذا السجل؟")) return;
    const map = {
      cars: [cars, setCars, "cars"],
      bookings: [bookings, setBookings, "bookings"],
      customers: [customers, setCustomers, "customers"],
      expenses: [expenses, setExpenses, "expenses"],
      loans: [loans, setLoans, "vehicle_loans"],
      maintenance: [
        maintenanceRecords,
        setMaintenanceRecords,
        "maintenance_records",
      ],
    };
    const [items, setItems, table] = map[type];
    if (remote && supabase) {
      const { error } = await supabase.from(table).delete().eq("id", id);
      if (error) {
        notify("تعذر الحذف: " + error.message);
        return;
      }
      await loadRemote();
    } else setItems(items.filter((x) => x.id !== id));
    notify("تم حذف السجل");
  }
  const filtered = (items) =>
    items.filter((x) =>
      JSON.stringify(x).toLowerCase().includes(search.toLowerCase()),
    );
  if (!authChecked)
    return (
      <div className="admin-auth-page" dir="rtl">
        <div className="admin-auth-card">
          <div className="auth-mark">
            <CarFront />
          </div>
          <h1>Elite Drive</h1>
          <p>جارٍ التحقق من جلسة الدخول…</p>
        </div>
      </div>
    );
  if (!user) return <AdminLogin supabase={supabase} onSignIn={signIn} />;
  return (
    <div className="app-shell">
      <aside className={"sidebar " + (mobileOpen ? "open" : "")}>
        <div className="brand">
          <div className="brand-mark">
            <CarFront size={24} />
          </div>
          <div>
            <b>
              <span>Elite</span> Drive
            </b>
            <small>إدارة وكالة كراء السيارات</small>
          </div>
          <button
            className="icon-btn close-menu"
            onClick={() => setMobileOpen(false)}
          >
            <X />
          </button>
        </div>
        <div className="side-label">القائمة الرئيسية</div>
        <nav>
          {nav.map(([id, label, Icon]) => (
            <button
              key={id}
              onClick={() => {
                setSection(id);
                setMobileOpen(false);
                setSearch("");
              }}
              className={"nav-item " + (section === id ? "active" : "")}
            >
              <Icon size={19} />
              <span>{label}</span>
              {id === "bookings" && (
                <em>{bookings.filter((b) => b.status === "pending").length}</em>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="secure-note">
            <ShieldCheck size={17} />
            <span>
              مساحة إدارة خاصة
              <br />
              <small>احمِ بيانات العملاء</small>
            </span>
          </div>
          <button className="nav-item" onClick={signOut}>
            <LogOut size={18} />
            <span>تسجيل الخروج</span>
          </button>
          <div className="user-mini">
            <div className="avatar">ED</div>
            <div>
              <b>{user?.email || "وضع المعاينة"}</b>
              <small>
                {remote ? "متصل بـ Supabase" : "بيانات تجريبية محلية"}
              </small>
            </div>
            <span className={"online " + (remote ? "" : "offline")}></span>
          </div>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div className="top-left">
            <button
              className="icon-btn mobile-toggle"
              onClick={() => setMobileOpen(true)}
            >
              <Menu />
            </button>
            <div>
              <div className="crumb">
                Elite Drive <ChevronLeft size={13} />{" "}
                <b>{nav.find((n) => n[0] === section)?.[1]}</b>
              </div>
              <div className="today">
                {new Date().toLocaleDateString("ar-MA", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </div>
            </div>
          </div>
          <div className="top-actions">
            <label className="searchbox">
              <Search size={17} />
              <input
                placeholder="ابحث في السجلات..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <kbd>⌘ K</kbd>
            </label>
            <button
              className="icon-btn notification"
              onClick={() => notify("لا توجد تنبيهات جديدة في هذه المعاينة")}
            >
              <Bell size={19} />
              <i />
            </button>
            <div className="top-avatar">ED</div>
          </div>
        </header>
        {!user && supabase && (
          <div className="connect-banner">
            <ShieldCheck size={19} />
            <span>
              قاعدة Supabase مهيأة. سجّل الدخول بحساب موظف معتمد للوصول إلى
              بيانات الوكالة.
            </span>
            <button
              onClick={() => setModal({ type: "login", title: "تسجيل الدخول" })}
            >
              تسجيل الدخول
            </button>
          </div>
        )}
        {!supabase && (
          <div className="demo-banner">
            <AlertTriangle size={18} />
            <span>
              <b>وضع المعاينة:</b> تعرض هذه الواجهة بيانات وهمية فقط ولا تحفظها
              في قاعدة بيانات. أضف مفاتيح Supabase في <code>.env</code> وشغّل
              SQL المرفق لتفعيل الاتصال.
            </span>
          </div>
        )}
        {section === "overview" && (
          <Dashboard
            cars={cars}
            bookings={bookings}
            expenses={expenses}
            totals={totals}
            loans={loans}
            payments={payments}
            maintenanceRecords={maintenanceRecords}
            setSection={setSection}
            setModal={setModal}
          />
        )}
        {section === "cars" && (
          <CarsPage
            cars={filtered(cars)}
            allCars={cars}
            setModal={setModal}
            remove={(id) => removeEntity("cars", id)}
          />
        )}
        {section === "bookings" && (
          <BookingsPage
            items={filtered(bookings)}
            allItems={bookings}
            cars={cars}
            customers={customers}
            site={site}
            setModal={setModal}
            remove={(id) => removeEntity("bookings", id)}
          />
        )}
        {section === "customers" && (
          <CustomersPage
            items={filtered(customers)}
            setModal={setModal}
            remove={(id) => removeEntity("customers", id)}
          />
        )}
        {section === "finance" && (
          <FinancePage
            profile={profile}
            bookings={bookings}
            expenses={filtered(expenses)}
            payments={filtered(payments)}
            totals={totals}
            setModal={setModal}
            remove={(id) => removeEntity("expenses", id)}
          />
        )}
        {section === "loans" && (
          <LoansPage
            items={filtered(loans)}
            setModal={setModal}
            remove={(id) => removeEntity("loans", id)}
          />
        )}
        {section === "maintenance" && (
          <MaintenancePage
            cars={cars}
            records={filtered(maintenanceRecords)}
            setModal={setModal}
            remove={(id) => removeEntity("maintenance", id)}
          />
        )}
        {section === "website" && (
          <WebsitePage
            profile={profile}
            site={site}
            setSite={setSite}
            remote={remote}
            notify={notify}
            supabase={supabase}
            user={user}
            logos={logos}
            setLogos={setLogos}
            sync={sync}
            refresh={() => loadRemote()}
          />
        )}
        {section === "reports" && (
          <ReportsPage
            cars={cars}
            bookings={bookings}
            expenses={expenses}
            totals={totals}
          />
        )}
        {section === "data" && (
          <DataPage
            profile={profile}
            supabase={supabase}
            remote={remote}
            cars={cars}
            bookings={bookings}
            customers={customers}
            expenses={expenses}
            payments={payments}
            loans={loans}
            maintenanceRecords={maintenanceRecords}
            site={site}
            setSite={setSite}
            setCars={setCars}
            setBookings={setBookings}
            setCustomers={setCustomers}
            setExpenses={setExpenses}
            setPayments={setPayments}
            setLoans={setLoans}
            setMaintenanceRecords={setMaintenanceRecords}
            refresh={loadRemote}
            notify={notify}
          />
        )}
        {section === "settings" && (
          <SettingsPage
            user={user}
            remote={remote}
            onLogin={() => setModal({ type: "login", title: "تسجيل الدخول" })}
            onRefresh={loadRemote}
            profile={profile}
            sync={sync}
            version={APP_VERSION}
          />
        )}
        <footer className="footer">
          <span>© {new Date().getFullYear()} Elite Drive</span>
          <span>
            <i className={"footer-dot " + (remote ? "green" : "orange")}></i>
            {remote
              ? "متصل بقاعدة البيانات"
              : "وضع معاينة — لا توجد بيانات حقيقية"}
          </span>
          <a href="/elite-drive-original.html" target="_blank">
            عرض صفحة HTML الأصلية
          </a>
        </footer>
      </main>
      {modal && (
        <Modal
          modal={modal}
          close={() => setModal(null)}
          save={saveEntity}
          signIn={signIn}
          cars={cars}
          customers={customers}
          bookings={bookings}
        />
      )}
      {toast && (
        <div className="toast">
          <CheckCircle2 size={18} />
          {toast}
        </div>
      )}
      {mobileOpen && (
        <div className="mobile-scrim" onClick={() => setMobileOpen(false)} />
      )}
    </div>
  );
}
function PageHead({ eyebrow, title, subtitle, action, children }) {
  return (
    <div className="page-head">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      <div className="head-actions">
        {children}
        {action}
      </div>
    </div>
  );
}
function AddButton({ onClick, label = "إضافة سجل جديد" }) {
  return (
    <button className="primary-btn" onClick={onClick}>
      <Plus size={18} />
      {label}
    </button>
  );
}
function Stat({ label, value, delta, Icon, tone = "gold", sub }) {
  return (
    <div className="stat-card">
      <div className={"stat-icon " + tone}>
        <Icon size={21} />
      </div>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      <div className="stat-foot">
        <span>
          {delta && (
            <>
              <TrendingUp size={13} />
              {delta}
            </>
          )}
        </span>
        <small>{sub || "حسب البيانات المسجلة"}</small>
      </div>
    </div>
  );
}
function Dashboard({
  cars,
  bookings,
  expenses,
  totals,
  loans,
  payments,
  maintenanceRecords,
  setSection,
  setModal,
}) {
  const monthly = totals.monthly || [];
  const max = Math.max(1, ...monthly.map((m) => Math.max(m.revenue, m.cost, 1)));
  return (
    <>
      <PageHead
        eyebrow="نظرة عامة"
        title="مرحباً بك في Elite Drive"
        subtitle="إليك ملخص أداء الوكالة وحالة الأسطول اليوم."
      >
        <button className="outline-btn" onClick={() => setSection("reports")}>
          <BarChart3 size={17} />
          عرض التقارير
        </button>
        <AddButton
          onClick={() =>
            setModal({ type: "bookings", title: "إنشاء حجز جديد" })
          }
          label="حجز جديد"
        />
      </PageHead>
      <div className="overview-grid">
        <Stat
          label="المداخيل المحصلة"
          value={money(totals.revenue)}
          delta="المبالغ المسجلة كمدفوعة"
          Icon={CircleDollarSign}
          tone="gold"
          sub="ليست توقعات أو حجوزات غير مدفوعة"
        />
        <Stat
          label="السيارات المتاحة"
          value={`${totals.available} / ${cars.length}`}
          delta="جاهزة للكراء"
          Icon={CarFront}
          tone="blue"
          sub="حسب حالة كل سيارة"
        />
        <Stat
          label="الحجوزات الجارية"
          value={totals.active}
          delta="عقود نشطة"
          Icon={CalendarDays}
          tone="purple"
          sub={`${bookings.filter((b) => b.status === "pending").length} طلبات في الانتظار`}
        />
        <Stat
          label="المبالغ المتبقية"
          value={money(totals.due)}
          delta="على الحجوزات المسجلة"
          Icon={Wallet}
          tone="orange"
          sub="لا تشمل ديوناً غير مسجلة"
        />
      </div>
      <div className="content-grid">
        <section className="panel chart-panel">
          <div className="panel-head">
            <div>
              <h2>نظرة مالية</h2>
              <p>إيرادات ومصاريف الشهور السبعة الأخيرة من السجلات الفعلية</p>
            </div>
            <button className="text-btn" onClick={() => setSection("finance")}>
              تفاصيل المالية <ArrowUpLeft size={15} />
            </button>
          </div>
          <div className="chart-summary">
            <div>
              <small>صافي نقدي مسجل</small>
              <strong>{money(totals.net)}</strong>
            </div>
            <div>
              <small>مصاريف مسجلة</small>
              <strong>{money(totals.cost)}</strong>
            </div>
          </div>
          <div className="bar-chart">
            {monthly.map((month) => (
              <div className="bar-col" key={month.label}>
                <span className="bar-value">
                  {(Math.max(month.revenue, month.cost) / 1000).toFixed(0)}k
                </span>
                <div className="bar-track">
                  <div
                    className="bar revenue-bar"
                    style={{ height: (month.revenue / max) * 100 + "%" }}
                    title={`الإيراد: ${money(month.revenue)}`}
                  />
                  <div
                    className="bar cost-bar"
                    style={{ height: (month.cost / max) * 100 + "%" }}
                    title={`المصاريف: ${money(month.cost)}`}
                  />
                </div>
                <small>{month.label}</small>
              </div>
            ))}
          </div>
          <div className="chart-legend">
            <span>
              <i className="legend-dot gold-dot" />
              الإيرادات المحصلة
            </span>
            <span>
              <i className="legend-dot orange-dot" />
              المصاريف
            </span>
          </div>
        </section>
        <section className="panel fleet-panel">
          <div className="panel-head">
            <div>
              <h2>حالة الأسطول</h2>
              <p>توزيع السيارات حسب الحالة</p>
            </div>
            <button className="icon-btn" onClick={() => setSection("cars")}>
              <ArrowUpLeft size={17} />
            </button>
          </div>
          <div className="fleet-ring-wrap">
            <div
              className="fleet-ring"
              style={{
                "--p": cars.length
                  ? (cars.filter((c) => c.status === "available").length /
                      cars.length) *
                    100
                  : 0,
              }}
            >
              <div>
                <strong>{cars.length}</strong>
                <small>سيارات</small>
              </div>
            </div>
            <div className="fleet-legend">
              <div>
                <i className="legend-dot gold-dot" />
                <span>متاحة</span>
                <b>{cars.filter((c) => c.status === "available").length}</b>
              </div>
              <div>
                <i className="legend-dot blue-dot" />
                <span>مكتراة</span>
                <b>{cars.filter((c) => c.status === "rented").length}</b>
              </div>
              <div>
                <i className="legend-dot orange-dot" />
                <span>صيانة</span>
                <b>{cars.filter((c) => c.status === "maintenance").length}</b>
              </div>
            </div>
          </div>
          <div className="fleet-note">
            <Activity size={16} />
            <span>راجع حالة السيارات قبل تأكيد أي حجز.</span>
          </div>
        </section>
      </div>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>آخر الحجوزات</h2>
            <p>متابعة آخر العمليات المسجلة</p>
          </div>
          <button className="text-btn" onClick={() => setSection("bookings")}>
            عرض كل الحجوزات <ArrowUpLeft size={15} />
          </button>
        </div>
        <BookingTable items={bookings.slice(0, 5)} />
      </section>
      <div className="overview-bottom">
        <section className="panel">
          <div className="panel-head">
            <div>
              <h2>تنبيهات تستحق الانتباه</h2>
              <p>مؤشرات بناءً على السجلات الحالية والمدفوعات</p>
            </div>
            <Bell size={18} />
          </div>
          <div className="alert-list">
            <div className="alert-row">
              <span className="alert-icon orange">
                <Clock3 />
              </span>
              <div>
                <b>مبالغ غير محصلة</b>
                <small>إجمالي المتبقي على الحجوزات المسجلة</small>
              </div>
              <strong>{money(totals.due)}</strong>
            </div>
            <div className="alert-row">
              <span className="alert-icon red">
                <Wrench />
              </span>
              <div>
                <b>سيارات في الصيانة</b>
                <small>تأكد من موعد العودة إلى الخدمة</small>
              </div>
              <strong>
                {maintenanceRecords.filter((r) => ["scheduled", "in_progress"].includes(r.status)).length}
              </strong>
            </div>
            <div className="alert-row">
              <span className="alert-icon blue">
                <Landmark />
              </span>
              <div>
                <b>قروض مسجلة</b>
                <small>أرصدة متبقية في سجلات التمويل</small>
              </div>
              <strong>
                {money(
                  loans.reduce(
                    (a, l) => a + Number(l.remaining_balance || 0),
                    0,
                  ),
                )}
              </strong>
            </div>
          </div>
        </section>
        <section className="panel quick-panel">
          <div className="panel-head">
            <div>
              <h2>إجراءات سريعة</h2>
              <p>اختصارات لتسيير العمل اليومي</p>
            </div>
          </div>
          <div className="quick-grid">
            <button
              onClick={() => setModal({ type: "cars", title: "إضافة سيارة" })}
            >
              <span className="quick-icon gold">
                <CarFront />
              </span>
              <b>إضافة سيارة</b>
              <small>تسجيل سيارة للأسطول</small>
            </button>
            <button
              onClick={() =>
                setModal({ type: "customers", title: "إضافة عميل" })
              }
            >
              <span className="quick-icon blue">
                <Users />
              </span>
              <b>إضافة عميل</b>
              <small>بيانات عميل جديد</small>
            </button>
            <button
              onClick={() =>
                setModal({ type: "expenses", title: "تسجيل مصروف" })
              }
            >
              <span className="quick-icon orange">
                <Wallet />
              </span>
              <b>تسجيل مصروف</b>
              <small>صيانة أو تشغيل أو غيره</small>
            </button>
            <button onClick={() => setSection("website")}>
              <span className="quick-icon purple">
                <Globe />
              </span>
              <b>تعديل الموقع</b>
              <small>إدارة محتوى الواجهة</small>
            </button>
          </div>
        </section>
      </div>
    </>
  );
}
function Table({ headers, children, empty = "لا توجد سجلات مطابقة" }) {
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            {headers.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {children || (
            <tr>
              <td colSpan={headers.length} className="empty">
                {empty}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
function CarsPage({ cars, allCars, setModal, remove }) {
  return (
    <>
      <PageHead
        eyebrow="إدارة الأصول"
        title="أسطول السيارات"
        subtitle={`إدارة بيانات السيارات والأسعار والتوفر — ${allCars.length} سيارة مسجلة.`}
        action={
          <AddButton
            onClick={() =>
              setModal({ type: "cars", title: "إضافة سيارة جديدة" })
            }
            label="إضافة سيارة"
          />
        }
      />
      <div className="mini-stats">
        <span>
          <b>{allCars.filter((c) => c.status === "available").length}</b> متاحة
        </span>
        <span>
          <b>{allCars.filter((c) => c.status === "rented").length}</b> مكتراة
        </span>
        <span>
          <b>{allCars.filter((c) => c.status === "maintenance").length}</b> في
          الصيانة
        </span>
      </div>
      <div className="cars-grid">
        {cars.map((c) => (
          <article className="car-admin-card" key={c.id}>
            <div className="car-admin-image">
              <img
                src={
                  c.image_url ||
                  "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=80"
                }
                onError={(e) =>
                  (e.currentTarget.src =
                    "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=80")
                }
              />
              <Status value={c.status} />
              <button
                className="image-edit"
                onClick={() =>
                  setModal({
                    type: "cars",
                    title: "تعديل بيانات السيارة",
                    data: c,
                  })
                }
              >
                <Pencil size={15} />
              </button>
            </div>
            <div className="car-admin-info">
              <div className="car-name-row">
                <h3>{c.name}</h3>
                <span>{c.year || "—"}</span>
              </div>
              <div className="plate">
                <CarFront size={14} />
                {c.plate || "دون رقم تسجيل"}
              </div>
              <div className="car-specs">
                <span>
                  <Gauge size={14} />
                  {Number(c.km || 0).toLocaleString("fr-MA")} كم
                </span>
                <span>{c.category || "غير مصنف"}</span>
              </div>
              <div className="car-price">
                <div>
                  <b>{money(c.daily_rate)}</b>
                  <small>لليوم</small>
                </div>
                <div>
                  <small>ثمن الشراء</small>
                  <b>{c.purchase_price ? money(c.purchase_price) : "—"}</b>
                </div>
              </div>
              <div className="card-actions">
                <button
                  className="outline-btn"
                  onClick={() =>
                    setModal({
                      type: "cars",
                      title: "تعديل بيانات السيارة",
                      data: c,
                    })
                  }
                >
                  <Pencil size={15} />
                  تعديل
                </button>
                <button
                  className="icon-btn danger"
                  onClick={() => remove(c.id)}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
      {cars.length === 0 && (
        <div className="panel empty-state">لا توجد سيارات تطابق البحث.</div>
      )}
    </>
  );
}
function BookingTable({ items, actions }) {
  return (
    <Table
      headers={[
        "العميل",
        "السيارة",
        "فترة الكراء",
        "المبلغ الإجمالي",
        "المتبقي",
        "الحالة",
        "",
      ]}
      empty="لا توجد حجوزات مسجلة."
    >
      {items.map((b) => (
        <tr key={b.id}>
          <td>
            <div className="customer-cell">
              <div className="avatar">
                {(b.customer_name || "ع").slice(0, 1)}
              </div>
              <b>{b.customer_name || "—"}</b>
            </div>
          </td>
          <td>{b.car_name || "—"}</td>
          <td>
            <div className="date-cell">
              <b>{dateLabel(b.start_date)}</b>
              <small>إلى {dateLabel(b.end_date)}</small>
            </div>
          </td>
          <td className="num">{money(b.total_amount)}</td>
          <td className="num due-num">
            {money(
              Math.max(
                0,
                Number(b.total_amount || 0) - Number(b.paid_amount || 0),
              ),
            )}
          </td>
          <td>
            <Status value={b.status} />
          </td>
          <td>{actions ? actions(b) : null}</td>
        </tr>
      ))}
    </Table>
  );
}
function printContract(booking, site) {
  const due = Math.max(0, Number(booking.total_amount || 0) - Number(booking.paid_amount || 0));
  const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>عقد كراء</title><style>
    body{font-family:Tahoma,Arial,sans-serif;padding:32px;color:#16181d}h1{margin:0 0 4px}h2{font-size:16px;margin:24px 0 8px}table{width:100%;border-collapse:collapse;margin-top:10px}td,th{border:1px solid #d8dce4;padding:9px;text-align:right}.meta{color:#626b7a}.total{font-size:20px;font-weight:bold}.sign{display:flex;gap:80px;margin-top:56px}.sign div{flex:1;border-top:1px solid #9aa1ad;padding-top:8px;text-align:center}@media print{button{display:none}}
  </style></head><body>
    <h1>${site.brand || "Elite Drive"}</h1><div class="meta">عقد كراء سيارة · ${new Date().toLocaleDateString("ar-MA")}</div>
    <h2>بيانات العقد</h2><table>
      <tr><th>العميل</th><td>${booking.customer_name || "—"}</td><th>السيارة</th><td>${booking.car_name || "—"}</td></tr>
      <tr><th>من</th><td>${dateLabel(booking.start_date)}</td><th>إلى</th><td>${dateLabel(booking.end_date)}</td></tr>
      <tr><th>السعر الإجمالي</th><td>${money(booking.total_amount)}</td><th>المؤدى</th><td>${money(booking.paid_amount)}</td></tr>
      <tr><th>المتبقي</th><td class="total">${money(due)}</td><th>الضمان</th><td>${money(booking.deposit_amount)}</td></tr>
      <tr><th>عداد التسليم</th><td>${booking.pickup_odometer || "—"}</td><th>عداد الإرجاع</th><td>${booking.return_odometer || "—"}</td></tr>
      <tr><th>ملاحظات</th><td colspan="3">${booking.notes || "—"}</td></tr>
    </table>
    <h2>إقرارات الطرفين</h2>
    <p>أقر العميل باستلام السيارة بحالتها الموثقة، والالتزام بإرجاعها في الموعد وبالوقود المتفق عليه، وتحمل أي أضرار أو مخالفات ناتجة عن الاستخدام.</p>
    <div class="sign"><div>توقيع الوكالة</div><div>توقيع العميل</div></div>
    <button onclick="window.print()">طباعة العقد</button>
  </body></html>`;
  const win = window.open("", "_blank", "noopener,noreferrer,width=900,height=700");
  if (!win) return;
  win.document.write(html);
  win.document.close();
}
function BookingCalendar({ cars, bookings }) {
  const days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });
  const iso = (d) => d.toISOString().slice(0, 10);
  return (
    <section className="panel booking-calendar-panel">
      <div className="panel-head">
        <div>
          <h2>تقويم التوفر</h2>
          <p>آخر 14 يوماً ابتداءً من اليوم — الألوان تعبر عن حجز قائم أو مؤكد أو جارٍ.</p>
        </div>
        <CalendarDays size={18} />
      </div>
      <div className="booking-calendar-wrap">
        <table className="booking-calendar">
          <thead>
            <tr>
              <th>السيارة</th>
              {days.map((d) => (
                <th key={iso(d)}>
                  <b>{d.toLocaleDateString("ar-MA", { day: "numeric" })}</b>
                  <small>{d.toLocaleDateString("ar-MA", { weekday: "short" })}</small>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {cars.map((car) => (
              <tr key={car.id}>
                <th>{car.name}</th>
                {days.map((d) => {
                  const day = iso(d);
                  const booking = bookings.find(
                    (b) =>
                      b.car_id === car.id &&
                      liveBookingStatuses.has(b.status) &&
                      b.start_date <= day &&
                      b.end_date >= day,
                  );
                  return (
                    <td key={day} className={booking ? "booked " + booking.status : "free"} title={booking ? `${booking.customer_name || ""} · ${dateLabel(booking.start_date)} - ${dateLabel(booking.end_date)}` : "متاحة"}>
                      {booking ? "محجوزة" : ""}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
function BookingsPage({ items, allItems, cars, customers, site, setModal, remove }) {
  const dueSoon = allItems.filter(
    (b) => b.status === "active" && b.end_date && new Date(b.end_date) >= new Date(),
  );
  const bookingActions = (b) => (
    <div className="row-actions">
      <button
        className="icon-btn"
        title="تعديل العقد"
        onClick={() =>
          setModal({ type: "bookings", title: "تعديل الحجز أو العقد", data: b })
        }
      >
        <Pencil size={15} />
      </button>
      <button className="icon-btn" title="طباعة العقد" onClick={() => printContract(b, site)}>
        <FileText size={15} />
      </button>
      <a
        className="icon-btn"
        title="إرسال تفاصيل عبر واتساب"
        target="_blank"
        rel="noreferrer"
        href={`https://wa.me/${normalizePhone(site.whatsapp)}?text=${encodeURIComponent(`السلام عليكم، تفاصيل حجزكم في ${site.brand || "Elite Drive"}:\nالسيارة: ${b.car_name || "—"}\nمن: ${b.start_date || "—"}\nإلى: ${b.end_date || "—"}\nالمبلغ: ${money(b.total_amount)}\nالمتبقي: ${money(Math.max(0, Number(b.total_amount || 0) - Number(b.paid_amount || 0)))}`)}`}
      >
        <Phone size={15} />
      </a>
      <button className="icon-btn danger" title="حذف" onClick={() => remove(b.id)}>
        <Trash2 size={15} />
      </button>
    </div>
  );
  return (
    <>
      <PageHead
        eyebrow="الحجوزات والعقود"
        title="إدارة عمليات الكراء"
        subtitle="إنشاء الحجز، منع التداخل، تتبع التسليم والإرجاع، وتوليد عقد قابل للطباعة."
        action={
          <AddButton
            onClick={() =>
              setModal({ type: "bookings", title: "إنشاء حجز جديد" })
            }
            label="إنشاء حجز"
          />
        }
      />
      <div className="mini-stats">
        <span><b>{items.length}</b> سجل ظاهر</span>
        <span><b>{items.filter((b) => b.status === "pending").length}</b> في الانتظار</span>
        <span><b>{items.filter((b) => b.status === "active").length}</b> جارية</span>
        <span><b>{items.filter((b) => b.status === "completed").length}</b> مكتملة</span>
        <span><b>{dueSoon.length}</b> إرجاع قادم</span>
      </div>
      <BookingCalendar cars={cars} bookings={allItems} />
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>سجل الحجوزات والعقود</h2>
            <p>استخدم أزرار التعديل والطباعة والواتساب من كل سطر.</p>
          </div>
        </div>
        <BookingTable items={items} actions={bookingActions} />
      </section>
      {dueSoon.length > 0 && (
        <section className="panel">
          <div className="panel-head">
            <div>
              <h2>عمليات إرجاع قادمة</h2>
              <p>العقود الجارية التي لم ينته موعدها بعد.</p>
            </div>
            <Bell size={18} />
          </div>
          <div className="alert-list">
            {dueSoon.slice(0, 5).map((b) => (
              <div className="alert-row" key={b.id}>
                <span className="alert-icon blue"><Clock3 /></span>
                <div><b>{b.car_name || "—"}</b><small>{b.customer_name || "—"}</small></div>
                <strong>{dateLabel(b.end_date)}</strong>
              </div>
            ))}
          </div>
        </section>
      )}
    </>
  );
}
function CustomersPage({ items, setModal, remove }) {
  return (
    <>
      <PageHead
        eyebrow="إدارة العلاقات"
        title="قاعدة بيانات العملاء"
        subtitle="ملفات العملاء وبيانات الاتصال وسجل الكراء والمبالغ المتبقية."
        action={
          <AddButton
            onClick={() => setModal({ type: "customers", title: "إضافة عميل" })}
            label="إضافة عميل"
          />
        }
      />
      <section className="panel table-panel">
        <Table
          headers={["العميل", "الهاتف", "البريد الإلكتروني", "رقم الهوية", ""]}
          empty="لا توجد بيانات عملاء."
        >
          {items.map((c) => (
            <tr key={c.id}>
              <td>
                <div className="customer-cell">
                  <div className="avatar">
                    {(c.full_name || "ع").slice(0, 1)}
                  </div>
                  <b>{c.full_name}</b>
                </div>
              </td>
              <td>{c.phone || "—"}</td>
              <td>{c.email || "—"}</td>
              <td>{c.identity_number || "—"}</td>
              <td>
                <button
                  className="icon-btn"
                  onClick={() =>
                    setModal({
                      type: "customers",
                      title: "تعديل بيانات العميل",
                      data: c,
                    })
                  }
                >
                  <Pencil size={15} />
                </button>
                <button
                  className="icon-btn danger"
                  onClick={() => remove(c.id)}
                >
                  <Trash2 size={15} />
                </button>
              </td>
            </tr>
          ))}
        </Table>
      </section>
    </>
  );
}
function FinancePage({ profile, bookings, expenses, payments, totals, setModal, remove }) {
  const canRecordPayment = ["owner", "admin", "manager", "accountant"].includes(profile?.role);
  return (
    <>
      <PageHead
        eyebrow="الإدارة المالية"
        title="المداخيل والمصاريف"
        subtitle="سجل التدفقات النقدية ومتابعة المبالغ المحصلة والمتبقية."
        action={
          <>
            {canRecordPayment && (
              <AddButton
                onClick={() =>
                  setModal({ type: "payments", title: "تسجيل دفعة حجز" })
                }
                label="تسجيل دفعة"
              />
            )}
            <AddButton
              onClick={() => setModal({ type: "expenses", title: "تسجيل مصروف" })}
              label="تسجيل مصروف"
            />
          </>
        }
      />
      <div className="overview-grid">
        <Stat
          label="مداخيل محصلة"
          value={money(totals.revenue)}
          Icon={ArrowDownLeft}
          tone="gold"
          sub="مدفوعات مسجلة فقط"
        />
        <Stat
          label="مصاريف مسجلة"
          value={money(totals.cost)}
          Icon={ArrowUpLeft}
          tone="orange"
        />
        <Stat
          label="صافي نقدي مبسط"
          value={money(totals.net)}
          Icon={TrendingUp}
          tone="blue"
          sub="المداخيل المحصلة ناقص المصاريف المسجلة فقط"
        />
        <Stat
          label="مبالغ مستحقة"
          value={money(totals.due)}
          Icon={Clock3}
          tone="purple"
          sub="لا يشمل الديون خارج الحجوزات"
        />
      </div>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>سجل المدفوعات</h2>
            <p>
              {totals.hasPaymentLedger
                ? "المصدر المعتمد للإيرادات هو جدول المدفوعات."
                : "لم تسجل مدفوعات بعد؛ تظهر القراءة الحالية من الحجوزات كوضع توافق قديم."}
            </p>
          </div>
        </div>
        <Table
          headers={["التاريخ", "الحجز", "الطريقة", "المرجع", "المبلغ", "الاتجاه"]}
          empty="لا توجد مدفوعات مسجلة."
        >
          {payments.map((p) => (
            <tr key={p.id}>
              <td>{dateLabel(p.payment_date)}</td>
              <td>{p.booking_label || p.booking_id || "—"}</td>
              <td>{{ cash: "نقداً", card: "بطاقة", transfer: "تحويل", other: "أخرى" }[p.method] || p.method || "—"}</td>
              <td>{p.reference || "—"}</td>
              <td className="num">{money(p.amount)}</td>
              <td>{p.direction === "refund" ? "استرجاع" : "دخل"}</td>
            </tr>
          ))}
        </Table>
      </section>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>سجل المصاريف</h2>
            <p>كل المصاريف التي تم إدخالها</p>
          </div>
          <button
            className="outline-btn"
            onClick={() => {
              const csv = [
                "التاريخ,الوصف,الفئة,المبلغ",
                "",
                ...expenses.map(
                  (e) =>
                    `${e.date || e.expense_date},${e.title},${e.category},${e.amount}`,
                ),
              ].join("\n");
              const blob = new Blob(["\ufeff" + csv], {
                type: "text/csv;charset=utf-8",
              });
              const a = document.createElement("a");
              a.href = URL.createObjectURL(blob);
              a.download = "elite-drive-expenses.csv";
              a.click();
              URL.revokeObjectURL(a.href);
            }}
          >
            <Download size={16} />
            تصدير CSV
          </button>
        </div>
        <Table
          headers={["التاريخ", "الوصف", "الفئة", "السيارة", "المبلغ", ""]}
          empty="لم تسجل مصاريف بعد."
        >
          {expenses.map((e) => (
            <tr key={e.id}>
              <td>{dateLabel(e.date || e.expense_date)}</td>
              <td>
                <b>{e.title}</b>
              </td>
              <td>
                {{
                  maintenance: "الصيانة",
                  insurance: "التأمين",
                  fuel: "الوقود",
                  tax: "الضرائب",
                  loan: "قسط قرض",
                  other: "أخرى",
                }[e.category] ||
                  e.category ||
                  "—"}
              </td>
              <td>{e.car_name || "—"}</td>
              <td className="num">{money(e.amount)}</td>
              <td>
                <button
                  className="icon-btn danger"
                  onClick={() => remove(e.id)}
                >
                  <Trash2 size={15} />
                </button>
              </td>
            </tr>
          ))}
        </Table>
      </section>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>ملخص الحجوزات والتحصيل</h2>
            <p>المبالغ الإجمالية والمدفوعة والمتبقية</p>
          </div>
        </div>
        <Table
          headers={[
            "الحجز",
            "العميل",
            "المبلغ الإجمالي",
            "المؤدى",
            "المتبقي",
            "الحالة",
          ]}
        >
          {bookings.map((b) => (
            <tr key={b.id}>
              <td>#{String(b.id).slice(0, 8)}</td>
              <td>{b.customer_name || "—"}</td>
              <td>{money(b.total_amount)}</td>
              <td className="num">{money(b.paid_amount)}</td>
              <td className="due-num">
                {money(Math.max(0, b.total_amount - b.paid_amount))}
              </td>
              <td>
                <Status value={b.status} />
              </td>
            </tr>
          ))}
        </Table>
      </section>
      <div className="info-panel panel">
        <ShieldCheck size={18} />
        <span>
          هذا ملخص إداري للتدفقات النقدية، وليس بديلاً عن المحاسبة القانونية أو
          التصريح الضريبي. يجب فصل أصل القرض عن الفوائد والإهلاك المحاسبي عند
          احتساب الربح.
        </span>
      </div>
    </>
  );
}
function LoansPage({ items, setModal, remove }) {
  const principal = items.reduce((a, l) => a + Number(l.principal || 0), 0),
    balance = items.reduce((a, l) => a + Number(l.remaining_balance || 0), 0);
  return (
    <>
      <PageHead
        eyebrow="التمويل والالتزامات"
        title="قروض شراء السيارات"
        subtitle="متابعة تمويل كل سيارة والأقساط والمواعيد والأرصدة المتبقية."
        action={
          <AddButton
            onClick={() =>
              setModal({ type: "loans", title: "إضافة قرض سيارة" })
            }
            label="إضافة قرض"
          />
        }
      />
      <div className="overview-grid">
        <Stat
          label="إجمالي أصل القروض"
          value={money(principal)}
          Icon={Landmark}
          tone="blue"
        />
        <Stat
          label="الرصيد المتبقي"
          value={money(balance)}
          Icon={Wallet}
          tone="orange"
        />
        <Stat
          label="القروض المسجلة"
          value={items.length}
          Icon={FileText}
          tone="purple"
        />
        <Stat
          label="الأقساط الشهرية"
          value={money(
            items.reduce((a, l) => a + Number(l.monthly_payment || 0), 0),
          )}
          Icon={CalendarDays}
          tone="gold"
        />
      </div>
      <section className="panel table-panel">
        <Table
          headers={[
            "الجهة الممولة",
            "السيارة",
            "أصل القرض",
            "القسط الشهري",
            "الرصيد المتبقي",
            "الاستحقاق القادم",
            "",
          ]}
          empty="لا توجد قروض مسجلة."
        >
          {items.map((l) => (
            <tr key={l.id}>
              <td>
                <b>{l.lender}</b>
              </td>
              <td>{l.car_name || "—"}</td>
              <td>{money(l.principal)}</td>
              <td>{money(l.monthly_payment)}</td>
              <td className="due-num">{money(l.remaining_balance)}</td>
              <td>{dateLabel(l.next_due_date)}</td>
              <td>
                <button
                  className="icon-btn"
                  onClick={() =>
                    setModal({ type: "loans", title: "تعديل القرض", data: l })
                  }
                >
                  <Pencil size={15} />
                </button>
                <button
                  className="icon-btn danger"
                  onClick={() => remove(l.id)}
                >
                  <Trash2 size={15} />
                </button>
              </td>
            </tr>
          ))}
        </Table>
      </section>
      <div className="panel info-panel">
        <AlertTriangle size={18} />
        <span>
          أدخل قيمة القرض والفائدة والمدة وجدول السداد الفعلي من عقد التمويل.
          الرصيد هنا لا يتناقص تلقائياً ما لم تسجل الدفعات وتفعّل منطق السداد.
        </span>
      </div>
    </>
  );
}
function MaintenancePage({ cars, records, setModal, remove }) {
  return (
    <>
      <PageHead
        eyebrow="الجاهزية والامتثال"
        title="الصيانة والوثائق"
        subtitle="متابعة حالة السيارات وتخطيط الصيانة والتأمين والفحص التقني."
        action={
          <AddButton
            onClick={() =>
              setModal({ type: "maintenance", title: "تسجيل مهمة صيانة" })
            }
            label="تسجيل صيانة"
          />
        }
      />
      <div className="cars-grid">
        {cars.map((c) => (
          <div className="maintenance-card panel" key={c.id}>
            <div className="maint-head">
              <div className="quick-icon orange">
                <Wrench />
              </div>
              <Status value={c.status} />
            </div>
            <h3>{c.name}</h3>
            <p>{c.plate || "دون رقم تسجيل"}</p>
            <div className="maint-row">
              <span>عداد السيارة</span>
              <b>{Number(c.km || 0).toLocaleString("fr-MA")} كم</b>
            </div>
            <div className="maint-row">
              <span>حالة الصيانة</span>
              <b>{c.status === "maintenance" ? "تحتاج متابعة" : "غير محددة"}</b>
            </div>
            <button
              className="outline-btn full"
              onClick={() =>
                setModal({
                  type: "maintenance",
                  title: "تسجيل مهمة صيانة",
                  data: { car_name: c.name, car_id: c.id },
                })
              }
            >
              <Plus size={15} />
              إضافة سجل صيانة
            </button>
          </div>
        ))}
      </div>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>سجل الصيانة</h2>
            <p>المهام المسجلة وتواريخها وتكاليفها</p>
          </div>
        </div>
        <Table
          headers={[
            "السيارة",
            "المهمة",
            "الحالة",
            "موعد الصيانة",
            "التكلفة",
            "",
          ]}
          empty="لا توجد مهام صيانة مسجلة."
        >
          {records.map((r) => (
            <tr key={r.id}>
              <td>
                {r.car_name || cars.find((c) => c.id === r.car_id)?.name || "—"}
              </td>
              <td>{r.title}</td>
              <td>
                <Status
                  value={
                    r.status === "scheduled"
                      ? "pending"
                      : r.status === "in_progress"
                        ? "active"
                        : r.status === "completed"
                          ? "completed"
                          : r.status
                  }
                />
              </td>
              <td>{dateLabel(r.due_date)}</td>
              <td>{money(r.cost)}</td>
              <td>
                <button
                  className="icon-btn danger"
                  onClick={() => remove(r.id)}
                >
                  <Trash2 size={15} />
                </button>
              </td>
            </tr>
          ))}
        </Table>
      </section>
      <div className="panel info-panel">
        <Clock3 size={18} />
        <span>
          تأكد من ربط سجل الصيانة بالسيارة الصحيحة، وأدخل التكاليف الفعلية عند
          إتمام العمل.
        </span>
      </div>
    </>
  );
}
function AdminLogin({ supabase, onSignIn }) {
  const [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const result = await onSignIn(email, password);
      if (result !== true)
        setError(result || "تعذر تسجيل الدخول. تحقق من بياناتك.");
    } catch (err) {
      setError(err.message || "حدث خطأ غير متوقع");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="admin-auth-page" dir="rtl">
      <div className="admin-auth-card">
        <Link to="/" className="auth-back">
          <ArrowUpLeft size={16} /> العودة إلى الموقع
        </Link>
        <div className="auth-mark">
          <CarFront size={28} />
        </div>
        <span className="auth-eyebrow">مساحة إدارية محمية</span>
        <h1>تسجيل الدخول</h1>
        <p>سجّل الدخول بحساب مدير معتمد للوصول إلى لوحة Elite Drive.</p>
        {!supabase && (
          <div className="auth-error">
            تعذر تهيئة Supabase. تأكد من متغيرات VITE_SUPABASE_URL
            وVITE_SUPABASE_ANON_KEY في البناء.
          </div>
        )}
        {error && <div className="auth-error">{error}</div>}
        <form onSubmit={submit}>
          <label>
            البريد الإلكتروني
            <input
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@example.com"
            />
          </label>
          <label>
            كلمة المرور
            <input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </label>
          <button
            className="primary-btn auth-submit"
            disabled={busy || !supabase}
          >
            {busy ? "جارٍ التحقق…" : "تسجيل الدخول الآمن"}
          </button>
        </form>
        <small>
          الوصول متاح للحسابات التي تحمل دور owner أو admin أو manager.
        </small>
      </div>
    </div>
  );
}

function WebsitePage({
  profile,
  site,
  setSite,
  remote,
  notify,
  supabase,
  user,
  logos,
  setLogos,
  sync,
  refresh,
}) {
  const isSiteAdmin = ["owner", "admin", "manager"].includes(profile?.role);
  const [form, setForm] = useState(site),
    [heroFile, setHeroFile] = useState(null),
    [heroPreview, setHeroPreview] = useState(""),
    [heroUploading, setHeroUploading] = useState(false),
    [logoUploading, setLogoUploading] = useState(false),
    [saving, setSaving] = useState(false),
    [syncError, setSyncError] = useState(""),
    [brokenLogos, setBrokenLogos] = useState({});
  useEffect(() => {
    setForm(site);
    setSyncError("");
  }, [site]);
  const update = (key, value) => setForm((old) => ({ ...old, [key]: value }));
  const save = async () => {
    if (!isSiteAdmin) return notify("هذا الدور لا يملك صلاحية تعديل صفحة الهبوط.");
    if (saving || heroUploading || logoUploading) return;
    setSaving(true);
    setSyncError("");
    try {
      if (!supabase || !remote || !user) {
        notify("سجّل الدخول واتصل بقاعدة البيانات قبل الحفظ المركزي.");
        setSaving(false);
        return;
      }
      const { saved } = await updateSiteSettings(supabase, form, user.id);
      setSite(saved);
      setForm(saved);
      await recordAudit(supabase, "settings.updated", "site_settings", 1, {
        fields: Object.keys(normalizeSettings(saved)),
      });
      await refresh();
      notify("تم حفظ إعدادات الموقع والتحقق منها في Supabase.");
    } catch (error) {
      console.error("updateSiteSettings", error);
      setSyncError(error.message || "تعذر حفظ إعدادات الموقع.");
      notify("تعذر حفظ إعدادات الموقع: " + (error.message || "خطأ غير معروف"));
    } finally {
      setSaving(false);
    }
  };
  const chooseHero = async (file) => {
    if (!file) return;
    setSyncError("");
    if (!isSiteAdmin) return notify("هذا الدور لا يملك صلاحية رفع صورة السلايدر.");
    if (!supabase || !remote || !user) {
      notify("يلزم تسجيل الدخول واتصال Supabase لرفع صورة السلايدر.");
      return;
    }
    if (!String(file.type).startsWith("image/")) {
      notify("اختر ملف صورة صالحاً.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      notify("حجم الصورة الأصلي يتجاوز 8 ميغابايت.");
      return;
    }
    const localPreview = URL.createObjectURL(file);
    setHeroFile(file);
    setHeroPreview(localPreview);
    setForm((old) => ({ ...old, hero_image: localPreview }));
    setHeroUploading(true);
    try {
      const uploaded = await uploadOptimizedSiteAsset(supabase, file, "hero", {
        maxWidth: 2000,
        maxHeight: 1250,
        quality: 0.86,
      });
      setHeroPreview("");
      setHeroFile(null);
      URL.revokeObjectURL(localPreview);
      setForm((old) => ({ ...old, hero_image: uploaded.url }));
      const { saved } = await updateSiteSettings(
        supabase,
        { ...form, hero_image: uploaded.url },
        user.id,
      );
      setSite(saved);
      setForm(saved);
      await refresh();
      notify("تم رفع صورة السلايدر، ضغطها، وحفظ رابطها بنجاح.");
    } catch (error) {
      console.error("hero upload", error);
      setSyncError(error.message || "تعذر رفع صورة السلايدر.");
      notify("تعذر رفع صورة السلايدر: " + (error.message || "تحقق من Storage"));
      setForm((old) => ({ ...old, hero_image: site.hero_image || "" }));
    } finally {
      setHeroUploading(false);
      if (heroPreview) URL.revokeObjectURL(heroPreview);
    }
  };
  const uploadLogo = async (fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    if (!isSiteAdmin) return notify("هذا الدور لا يملك صلاحية رفع الشعارات.");
    if (!supabase || !remote || !user) {
      notify("سجّل الدخول واتصل بقاعدة البيانات قبل رفع الشعارات.");
      return;
    }
    setLogoUploading(true);
    setSyncError("");
    let next = [...logos];
    try {
      for (const file of files) {
        if (!String(file.type).startsWith("image/")) throw new Error(`الملف ${file.name} ليس صورة.`);
        const uploaded = await uploadOptimizedSiteAsset(supabase, file, "brand-logos", {
          maxWidth: 720,
          maxHeight: 360,
          quality: 0.9,
          maxBytes: 300 * 1024,
        });
        next = [
          ...next,
          {
            name: file.name,
            url: uploaded.url,
            path: uploaded.path,
            uploaded_at: new Date().toISOString(),
          },
        ];
      }
      const saved = await saveBrandLogos(supabase, next);
      setLogos(saved);
      setBrokenLogos({});
      notify("تم رفع الشعارات وتحديث ترتيبها بنجاح.");
    } catch (error) {
      console.error("logo upload", error);
      setSyncError(error.message || "تعذر رفع الشعارات.");
      notify("تعذر رفع الشعارات: " + (error.message || "تحقق من Storage"));
    } finally {
      setLogoUploading(false);
    }
  };
  const persistLogos = async (next) => {
    if (!isSiteAdmin) return notify("هذا الدور لا يملك صلاحية تعديل الشعارات.");
    if (!supabase || !remote) return;
    try {
      const saved = await saveBrandLogos(supabase, next);
      setLogos(saved);
    } catch (error) {
      console.error("save logos", error);
      notify("تعذر حفظ ترتيب الشعارات: " + error.message);
    }
  };
  const moveLogo = (index, direction) => {
    const target = index + direction;
    if (target < 0 || target >= logos.length) return;
    const next = [...logos];
    [next[index], next[target]] = [next[target], next[index]];
    setLogos(next);
    persistLogos(next);
  };
  const removeLogo = async (index) => {
    const removed = logos[index];
    const next = logos.filter((_, i) => i !== index);
    try {
      if (supabase && remote) {
        await saveBrandLogos(supabase, next);
        if (removed?.path) {
          const { error } = await supabase.storage.from("site-assets").remove([removed.path]);
          if (error) console.warn("تعذر حذف ملف الشعار من Storage", error);
        }
      }
      setLogos(next);
      notify("تم حذف الشعار من الواجهة.");
    } catch (error) {
      notify("تعذر حذف الشعار: " + error.message);
    }
  };
  const heroBackground = form.hero_image || site.hero_image || "";
  return (
    <>
      <PageHead
        eyebrow="إدارة المحتوى"
        title="تخصيص صفحة الهبوط"
        subtitle="كل حفظ يكتب إلى سجل الإعدادات المركزي ثم يعاد قراءته للتحقق قبل عرض النجاح."
        action={
          <>
            <button className="outline-btn" onClick={refresh} disabled={sync.loading}>
              <Activity size={16} />
              {sync.loading ? "جارٍ التحديث…" : "تحديث المعاينة"}
            </button>
            <button className="primary-btn" onClick={save} disabled={!isSiteAdmin || saving || heroUploading || logoUploading}>
              <CheckCircle2 size={17} />
              {saving ? "جارٍ الحفظ والتحقق…" : "حفظ التغييرات"}
            </button>
          </>
        }
      />
      {syncError && <div className="sync-error">{syncError}</div>}
      <div className="sync-line">
        <span>
          آخر مزامنة ناجحة:{" "}
          {sync.at ? sync.at.toLocaleString("ar-MA") : "لم تتم بعد"}
        </span>
        {sync.error && <b>{sync.error}</b>}
      </div>
      <div className="website-layout">
        <section className="panel form-panel">
          <div className="panel-head">
            <div>
              <h2>الهوية والمحتوى</h2>
              <p>هذه القيم هي المصدر المعتمد لصفحة الزوار والمعاينة.</p>
            </div>
            <Globe size={19} />
          </div>
          <Field
            label="اسم الوكالة"
            value={form.brand || ""}
            onChange={(v) => update("brand", v)}
            required
          />
          <Field
            label="عنوان السلايدر الرئيسي"
            value={form.hero_title || ""}
            onChange={(v) => update("hero_title", v)}
            required
          />
          <Field
            label="النص التوضيحي"
            value={form.hero_subtitle || ""}
            onChange={(v) => update("hero_subtitle", v)}
          />
          <Field
            label="رقم واتساب بصيغة دولية دون +"
            value={form.whatsapp || ""}
            onChange={(v) => update("whatsapp", normalizePhone(v, form.whatsapp))}
            required
          />
          <Field
            label="المدينة أو منطقة الخدمة"
            value={form.city || ""}
            onChange={(v) => update("city", v)}
          />
          <Field
            label="العنوان"
            value={form.address || ""}
            onChange={(v) => update("address", v)}
          />
          <Field
            label="البريد الإلكتروني للتواصل"
            type="email"
            value={form.contact_email || ""}
            onChange={(v) => update("contact_email", v)}
          />
          <Field
            label="رابط الشعار"
            value={form.logo_url || ""}
            onChange={(v) => update("logo_url", v)}
            placeholder="https://..."
          />
          <div className="field">
            <label>لون الهوية</label>
            <div className="color-row">
              <input
                type="color"
                value={form.accent || "#d4af37"}
                onChange={(e) => update("accent", e.target.value)}
              />
              <code>{form.accent}</code>
            </div>
          </div>
          <div className="span-2 upload-block">
            <label>صورة السلايدر</label>
            <div className="hero-upload-row">
              <label className="upload-logo-btn">
                <Image size={17} />
                {heroUploading ? "جارٍ ضغط الصورة والرفع…" : "اختيار صورة من الهاتف أو الحاسوب"}
                <input
                  type="file"
                  accept="image/*"
                  disabled={!isSiteAdmin || heroUploading || saving}
                  onChange={(e) => {
                    chooseHero(e.target.files?.[0]);
                    e.target.value = "";
                  }}
                />
              </label>
              {heroUploading && <span className="upload-progress">يتم الرفع والتحقق…</span>}
            </div>
            {heroPreview && (
              <div className="image-upload-preview">
                <img src={heroPreview} alt="معاينة صورة السلايدر قبل الحفظ" />
                <small>معاينة محلية قبل اكتمال الرفع والحفظ المركزي.</small>
              </div>
            )}
            <p className="form-hint">
              يتم ضغط الصورة تلقائياً وتحويلها إلى WebP عند دعم المتصفح، ثم حفظ رابطها في سجل الإعدادات.
            </p>
          </div>
          <div className="brand-logo-manager">
            <div className="panel-head">
              <div>
                <h2>شريط شعارات السيارات</h2>
                <p>يمكن رفع أكثر من شعار، تغيير الترتيب، أو حذفه من قاعدة البيانات والتخزين.</p>
              </div>
            </div>
            <label className="upload-logo-btn">
              <Image size={17} />
              {logoUploading ? "جارٍ رفع الشعارات…" : "رفع شعارات متعددة"}
              <input
                type="file"
                accept="image/*"
                multiple
                disabled={!isSiteAdmin || logoUploading}
                onChange={(e) => {
                  uploadLogo(e.target.files);
                  e.target.value = "";
                }}
              />
            </label>
            <div className="logo-admin-list">
              {logos.map((logo, i) => (
                <div className="logo-admin-item" key={logo.path || logo.url || i}>
                  {brokenLogos[logo.url] ? (
                    <span className="broken-logo">تعذر تحميل الشعار</span>
                  ) : (
                    <img
                      src={logo.url}
                      alt={logo.name || "شعار سيارة"}
                      loading="lazy"
                      onError={() => setBrokenLogos((old) => ({ ...old, [logo.url]: true }))}
                    />
                  )}
                  <span>{logo.name}</span>
                  <button type="button" className="icon-btn" onClick={() => moveLogo(i, -1)} aria-label="تقديم الشعار">↑</button>
                  <button type="button" className="icon-btn" onClick={() => moveLogo(i, 1)} aria-label="تأخير الشعار">↓</button>
                  <button type="button" className="icon-btn danger" onClick={() => removeLogo(i)} aria-label="حذف الشعار">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
              {!logos.length && (
                <p className="form-hint">
                  لم ترفع شعارات بعد. اختر PNG أو SVG أو WebP من جهازك.
                </p>
              )}
            </div>
          </div>
        </section>
        <section className="preview-panel">
          <div className="preview-top">
            <span>
              <i />
              معاينة مباشرة
            </span>
            <button className="text-btn" onClick={refresh}>
              تحديث
            </button>
          </div>
          <div
            className="hero-preview"
            style={{
              backgroundImage: heroBackground
                ? `linear-gradient(90deg,rgba(5,6,8,.88),rgba(5,6,8,.35)),url('${heroBackground}')`
                : "linear-gradient(135deg,#101114,#1b1d23)",
            }}
          >
            <div className="preview-brand">
              {form.logo_url ? (
                <img className="preview-logo" src={form.logo_url} alt="" />
              ) : (
                <CarFront size={20} />
              )}
              <b>{form.brand || "Elite Drive"}</b>
            </div>
            <div className="preview-copy">
              <span>كراء السيارات باحترافية</span>
              <h2>{form.hero_title || "عنوان السلايدر"}</h2>
              <p>{form.hero_subtitle || "النص التوضيحي"}</p>
              <button style={{ background: form.accent || "#d4af37" }}>
                استكشف السيارات ←
              </button>
            </div>
          </div>
          <div className="preview-foot">
            <span>
              <MapPin size={14} />
              {form.city || "المدينة"}
            </span>
            <span>
              <Phone size={14} />
              {form.whatsapp || "رقم واتساب"}
            </span>
          </div>
          <div className="info-panel">
            <ShieldCheck size={17} />
            <span>
              هذه المعاينة تستخدم نفس قيم `site_settings` التي تقرأها الصفحة العامة بعد الحفظ.
            </span>
          </div>
        </section>
      </div>
    </>
  );
}
function ReportsPage({ cars, bookings, expenses, totals }) {
  const rows = [
    ["عدد السيارات", cars.length],
    ["الحجوزات المسجلة", bookings.length],
    [
      "الحجوزات المكتملة",
      bookings.filter((b) => b.status === "completed").length,
    ],
    [
      "معدل إشغال الأسطول",
      cars.length
        ? Math.round(
            (cars.filter((c) => c.status === "rented").length / cars.length) *
              100,
          ) + "%"
        : "0%",
    ],
    ["المداخيل المحصلة", money(totals.revenue)],
    ["المصاريف المسجلة", money(totals.cost)],
    ["المبالغ المتبقية", money(totals.due)],
    ["صافي نقدي مبسط", money(totals.net)],
  ];
  return (
    <>
      <PageHead
        eyebrow="البيانات ومؤشرات الأداء"
        title="التقارير والتحليلات"
        subtitle="مؤشرات محسوبة من السجلات الحالية. البيانات الافتراضية للتجربة فقط."
        action={
          <button
            className="outline-btn"
            onClick={() => {
              const csv = [
                "المؤشر,القيمة",
                ...rows.map((r) => r.join(",")),
              ].join("\n");
              const a = document.createElement("a");
              a.href = URL.createObjectURL(
                new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" }),
              );
              a.download = "elite-drive-report.csv";
              a.click();
              URL.revokeObjectURL(a.href);
            }}
          >
            <Download size={16} />
            تصدير التقرير
          </button>
        }
      />
      <div className="report-grid">
        {rows.map(([k, v], i) => (
          <div className="report-card panel" key={k}>
            <div className="report-number">
              {String(i + 1).padStart(2, "0")}
            </div>
            <small>{k}</small>
            <b>{v}</b>
          </div>
        ))}
      </div>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>أداء السيارات</h2>
            <p>إيرادات الحجز حسب السيارة (قبل احتساب التكاليف)</p>
          </div>
        </div>
        <Table
          headers={[
            "السيارة",
            "الحجوزات",
            "المداخيل الإجمالية",
            "المبالغ المحصلة",
            "المتبقي",
          ]}
        >
          {cars.map((c) => {
            const bs = bookings.filter((b) => b.car_name === c.name);
            return (
              <tr key={c.id}>
                <td>
                  <b>{c.name}</b>
                </td>
                <td>{bs.length}</td>
                <td>
                  {money(
                    bs.reduce((a, b) => a + Number(b.total_amount || 0), 0),
                  )}
                </td>
                <td>
                  {money(
                    bs.reduce((a, b) => a + Number(b.paid_amount || 0), 0),
                  )}
                </td>
                <td>
                  {money(
                    bs.reduce(
                      (a, b) =>
                        a +
                        Math.max(
                          0,
                          Number(b.total_amount || 0) -
                            Number(b.paid_amount || 0),
                        ),
                      0,
                    ),
                  )}
                </td>
              </tr>
            );
          })}
        </Table>
      </section>
      <div className="info-panel panel">
        <AlertTriangle size={18} />
        <span>
          نسبة الإشغال الحالية مبنية على حالة السيارة فقط. التقارير المحاسبية
          النهائية تحتاج احتساب الفترات المتاحة وأيام الكراء الفعلية والإهلاك
          والفوائد والضرائب.
        </span>
      </div>
    </>
  );
}
function SettingsPage({ user, remote, onLogin, onRefresh, profile, sync, version }) {
  const role = profile?.role || "غير محدد";
  const matrix = [
    ["owner", "مالك النظام", "كل الصلاحيات مع حماية الحساب الرئيسي"],
    ["admin", "مدير", "إدارة العمليات والمحتوى والفريق"],
    ["manager", "مدير عمليات", "إدارة الحجوزات والسيارات والعملاء"],
    ["staff", "موظف", "عمليات التشغيل اليومية حسب سياسات RLS"],
    ["accountant", "محاسب", "المدفوعات والمصاريف والتقارير المالية"],
    ["viewer", "مشاهد", "قراءة محدودة فقط"],
  ];
  return (
    <>
      <PageHead
        eyebrow="إعداد المنصة"
        title="الإعدادات والأمان"
        subtitle="حالة الاتصال وقاعدة البيانات والدور الحالي ومستوى الوصول."
      />
      <div className="sync-line">
        <span>إصدار التطبيق: {version}</span>
        <span>آخر مزامنة: {sync?.at ? sync.at.toLocaleString("ar-MA") : "لم تتم"}</span>
        {sync?.error && <b>{sync.error}</b>}
      </div>
      <div className="settings-grid">
        <section className="panel setting-card">
          <div className="setting-icon"><Database /></div>
          <h3>اتصال Supabase</h3>
          <p>{remote ? "تم تحميل بيانات من قاعدة البيانات وربطها بالواجهة." : "لم يتم تفعيل الاتصال أو لم يكتمل تسجيل الدخول."}</p>
          <span className={"status " + (remote ? "green" : "orange")}><i />{remote ? "متصل" : "غير متصل"}</span>
          <button className="outline-btn full" onClick={onRefresh}>تحديث البيانات</button>
        </section>
        <section className="panel setting-card">
          <div className="setting-icon"><ShieldCheck /></div>
          <h3>المصادقة والدور</h3>
          <p>الحساب: {user?.email || "غير مسجل"}<br />الدور الفعلي من قاعدة البيانات: <b>{role}</b></p>
          <button className="primary-btn full" onClick={onLogin}>تسجيل الدخول</button>
        </section>
        <section className="panel setting-card">
          <div className="setting-icon"><CreditCard /></div>
          <h3>العملة واللغة</h3>
          <p>العملة الافتراضية: الدرهم المغربي (MAD). واجهة الإدارة بالعربية واتجاه RTL.</p>
          <span className="tag">MAD · ar-MA</span>
        </section>
        <section className="panel setting-card">
          <div className="setting-icon"><FileText /></div>
          <h3>سياسات RLS</h3>
          <p>تم رفع القرار الأمني إلى PostgreSQL وعدم الاعتماد على localStorage أو قيم الواجهة القابلة للتزوير.</p>
          <span className="tag">RLS مفعّل</span>
        </section>
      </div>
      <section className="panel table-panel">
        <div className="panel-head">
          <div>
            <h2>مصفوفة الأدوار المعتمدة</h2>
            <p>هذه الأدوار موجودة في مخطط قاعدة البيانات الحالي، وتطبقها السياسات على الخادم.</p>
          </div>
          <ShieldCheck size={18} />
        </div>
        <Table headers={["الدور", "الاسم", "نطاق العمل"]}>
          {matrix.map(([value, label, scope]) => (
            <tr key={value} className={role === value ? "active-role" : ""}>
              <td><code>{value}</code></td>
              <td>{label}</td>
              <td>{scope}</td>
            </tr>
          ))}
        </Table>
      </section>
    </>
  );
}
function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder = "",
  required = false,
}) {
  return (
    <div className="field">
      <label>
        {label}
        {required && <i> *</i>}
      </label>
      <input
        type={type}
        value={value ?? ""}
        placeholder={placeholder}
        required={required}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
function SelectField({ label, value, onChange, options, required = false }) {
  return (
    <div className="field">
      <label>{label}</label>
      <select
        value={value || ""}
        required={required}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="">اختر...</option>
        {options.map((o) => (
          <option value={o.value} key={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}
function Modal({ modal, close, save, signIn, cars, customers, bookings }) {
  const [data, setData] = useState(modal.data || {});
  const [carImageUploading, setCarImageUploading] = useState(false);
  const [carImageError, setCarImageError] = useState("");
  const update = (k, v) => setData((p) => ({ ...p, [k]: v }));
  const type = modal.type;
  const submit = (e) => {
    e.preventDefault();
    if (type === "login") {
      signIn(data.email, data.password);
      close();
      return;
    }
    save(type, data);
  };
  if (type === "login")
    return (
      <div className="modal-backdrop" onMouseDown={close}>
        <form
          className="modal"
          onSubmit={submit}
          onMouseDown={(e) => e.stopPropagation()}
        >
          <div className="modal-head">
            <div>
              <span className="eyebrow">مساحة آمنة</span>
              <h2>{modal.title}</h2>
            </div>
            <button type="button" className="icon-btn" onClick={close}>
              <X />
            </button>
          </div>
          <div className="modal-body">
            <Field
              label="البريد الإلكتروني"
              type="email"
              value={data.email || ""}
              onChange={(v) => update("email", v)}
              required
            />
            <Field
              label="كلمة المرور"
              type="password"
              value={data.password || ""}
              onChange={(v) => update("password", v)}
              required
            />
            <p className="form-hint">
              لا يوجد حساب افتراضي. أنشئ المستخدم من Supabase Auth ثم امنحه
              صلاحية الموظف عبر جدول profiles.
            </p>
          </div>
          <div className="modal-actions">
            <button type="button" className="outline-btn" onClick={close}>
              إلغاء
            </button>
            <button className="primary-btn" type="submit">
              تسجيل الدخول
            </button>
          </div>
        </form>
      </div>
    );
  const title = modal.title;
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <form
        className="modal"
        onSubmit={submit}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="modal-head">
          <div>
            <span className="eyebrow">Elite Drive</span>
            <h2>{title}</h2>
          </div>
          <button type="button" className="icon-btn" onClick={close}>
            <X />
          </button>
        </div>
        <div className="modal-body">
          <div className="form-grid">
            {type === "cars" && (
              <>
                <Field
                  label="اسم السيارة والموديل"
                  value={data.name || ""}
                  onChange={(v) => update("name", v)}
                  required
                />
                <Field
                  label="رقم التسجيل"
                  value={data.plate || ""}
                  onChange={(v) => update("plate", v)}
                />
                <SelectField
                  label="الفئة"
                  value={data.category || ""}
                  onChange={(v) => update("category", v)}
                  options={[
                    { value: "اقتصادية", label: "اقتصادية" },
                    { value: "مدمجة", label: "مدمجة" },
                    { value: "SUV", label: "SUV" },
                    { value: "فاخرة", label: "فاخرة" },
                    { value: "نفعية", label: "نفعية" },
                  ]}
                />
                <Field
                  label="سنة الصنع"
                  type="number"
                  value={data.year || ""}
                  onChange={(v) => update("year", v)}
                />
                <Field
                  label="الثمن اليومي (درهم)"
                  type="number"
                  value={data.daily_rate || ""}
                  onChange={(v) => update("daily_rate", v)}
                  required
                />
                <Field
                  label="عداد الكيلومترات"
                  type="number"
                  value={data.km || ""}
                  onChange={(v) => update("km", v)}
                />
                <Field
                  label="ثمن الشراء (درهم)"
                  type="number"
                  value={data.purchase_price || ""}
                  onChange={(v) => update("purchase_price", v)}
                />
                <SelectField
                  label="الحالة"
                  value={data.status || "available"}
                  onChange={(v) => update("status", v)}
                  options={[
                    { value: "available", label: "متاحة" },
                    { value: "rented", label: "مكتراة" },
                    { value: "maintenance", label: "في الصيانة" },
                    { value: "unavailable", label: "غير متاحة" },
                  ]}
                />
                <div className="span-2 car-image-uploader">
                  <label className="field-label" htmlFor="car-image-file">صورة السيارة (ارفعها من الهاتف أو اختر صورة من الملفات)</label>
                  <input
                    id="car-image-file"
                    type="file"
                    accept="image/*"
                    className="car-image-file-input"
                    disabled={carImageUploading}
                    onChange={async (event) => {
                      const file = event.target.files?.[0];
                      if (!file) return;
                      setCarImageError("");
                      setCarImageUploading(true);
                      try {
                        if (!supabase) throw new Error("اتصال Supabase غير متاح.");
                        const { data: authData } = await supabase.auth.getUser();
                        if (!authData?.user) throw new Error("سجّل الدخول إلى لوحة الإدارة أولاً.");
                        const uploaded = await uploadOptimizedSiteAsset(supabase, file, "car-images", {
                          maxWidth: 1600, maxHeight: 1200, maxBytes: 850 * 1024,
                        });
                        update("image_url", uploaded.url);
                      } catch (error) {
                        setCarImageError(error.message || "تعذر رفع صورة السيارة.");
                      } finally {
                        setCarImageUploading(false);
                        event.target.value = "";
                      }
                    }}
                  />
                  <p className="form-hint">يدعم صور JPG وPNG وWebP من المعرض أو الكاميرا. سيتم ضغط الصورة ورفعها إلى تخزين الموقع ثم حفظ رابطها مع السيارة.</p>
                  {carImageUploading && <p className="upload-progress">جارٍ ضغط الصورة ورفعها…</p>}
                  {carImageError && <p className="form-error">{carImageError}</p>}
                  <Field
                    label="أو أدخل رابط صورة مباشرة"
                    value={data.image_url || ""}
                    onChange={(v) => update("image_url", v)}
                    placeholder="https://..."
                  />
                  {data.image_url && <img className="car-image-upload-preview" src={data.image_url} alt="معاينة صورة السيارة" onError={(e) => { e.currentTarget.style.display = "none"; }} />}
                </div>
              </>
            )}
            {type === "customers" && (
              <>
                <Field
                  label="الاسم الكامل"
                  value={data.full_name || ""}
                  onChange={(v) => update("full_name", v)}
                  required
                />
                <Field
                  label="رقم الهاتف"
                  value={data.phone || ""}
                  onChange={(v) => update("phone", v)}
                  required
                />
                <Field
                  label="البريد الإلكتروني"
                  type="email"
                  value={data.email || ""}
                  onChange={(v) => update("email", v)}
                />
                <Field
                  label="رقم بطاقة التعريف"
                  value={data.identity_number || ""}
                  onChange={(v) => update("identity_number", v)}
                />
                <Field
                  label="رقم رخصة السياقة"
                  value={data.license_number || ""}
                  onChange={(v) => update("license_number", v)}
                />
                <Field
                  label="تاريخ انتهاء الرخصة"
                  type="date"
                  value={data.license_expiry || ""}
                  onChange={(v) => update("license_expiry", v)}
                />
                <div className="span-2">
                  <Field
                    label="العنوان"
                    value={data.address || ""}
                    onChange={(v) => update("address", v)}
                  />
                </div>
              </>
            )}
            {type === "bookings" && (
              <>
                <SelectField
                  label="العميل"
                  value={data.customer_id || ""}
                  onChange={(v) => update("customer_id", v)}
                  options={customers.map((c) => ({
                    value: c.id,
                    label: c.full_name || c.phone || c.id,
                  }))}
                  required
                />
                <SelectField
                  label="السيارة"
                  value={data.car_id || ""}
                  onChange={(v) => {
                    const car = cars.find((c) => c.id === v);
                    update("car_id", v);
                    update("daily_rate", car?.daily_rate || "");
                  }}
                  options={cars.map((c) => ({
                    value: c.id,
                    label: `${c.name || ""} · ${money(c.daily_rate)}`,
                  }))}
                  required
                />
                <Field
                  label="تاريخ بداية الكراء"
                  type="date"
                  value={data.start_date || ""}
                  onChange={(v) => update("start_date", v)}
                  required
                />
                <Field
                  label="تاريخ نهاية الكراء"
                  type="date"
                  value={data.end_date || ""}
                  onChange={(v) => update("end_date", v)}
                  required
                />
                <Field
                  label="السعر اليومي"
                  type="number"
                  value={data.daily_rate || cars.find((c) => c.id === data.car_id)?.daily_rate || ""}
                  onChange={(v) => update("daily_rate", v)}
                  required
                />
                <Field
                  label="الخصم (اختياري)"
                  type="number"
                  value={data.discount_amount || 0}
                  onChange={(v) => update("discount_amount", v)}
                />
                <Field
                  label="المبلغ الإجمالي"
                  type="number"
                  value={data.total_amount || ""}
                  onChange={(v) => update("total_amount", v)}
                  placeholder="اتركه فارغاً لحسابه تلقائياً"
                />
                <SelectField
                  label="الحالة"
                  value={data.status || "pending"}
                  onChange={(v) => update("status", v)}
                  options={[
                    { value: "pending", label: "في الانتظار" },
                    { value: "confirmed", label: "مؤكد" },
                    { value: "active", label: "جارية" },
                    { value: "completed", label: "مكتملة" },
                    { value: "cancelled", label: "ملغاة" },
                  ]}
                />
                <Field
                  label="مبلغ الضمان"
                  type="number"
                  value={data.deposit_amount || 0}
                  onChange={(v) => update("deposit_amount", v)}
                />
                <Field
                  label="وقت التسليم"
                  type="time"
                  value={data.pickup_time || ""}
                  onChange={(v) => update("pickup_time", v)}
                />
                <Field
                  label="وقت الإرجاع"
                  type="time"
                  value={data.return_time || ""}
                  onChange={(v) => update("return_time", v)}
                />
                <Field
                  label="عداد التسليم"
                  type="number"
                  value={data.pickup_odometer || ""}
                  onChange={(v) => update("pickup_odometer", v)}
                />
                <Field
                  label="عداد الإرجاع"
                  type="number"
                  value={data.return_odometer || ""}
                  onChange={(v) => update("return_odometer", v)}
                />
                <Field
                  label="مستوى وقود التسليم %"
                  type="number"
                  value={data.pickup_fuel_level || ""}
                  onChange={(v) => update("pickup_fuel_level", v)}
                />
                <Field
                  label="مستوى وقود الإرجاع %"
                  type="number"
                  value={data.return_fuel_level || ""}
                  onChange={(v) => update("return_fuel_level", v)}
                />
                <Field
                  label="غرامة التأخر"
                  type="number"
                  value={data.late_fee || 0}
                  onChange={(v) => update("late_fee", v)}
                />
                <Field
                  label="حالة الأضرار"
                  value={data.damage_description || ""}
                  onChange={(v) => update("damage_description", v)}
                />
                <div className="span-2">
                  <Field
                    label="ملاحظات العقد"
                    value={data.notes || ""}
                    onChange={(v) => update("notes", v)}
                  />
                </div>
                <p className="form-hint span-2">
                  يحسب التطبيق السعر اليومي ومدة الكراء عند غياب المبلغ الإجمالي، ثم تمنع قاعدة البيانات أي تداخل فعلي في التواريخ.
                </p>
              </>
            )}
            {type === "payments" && (
              <>
                <SelectField
                  label="الحجز"
                  value={data.booking_id || ""}
                  onChange={(v) => update("booking_id", v)}
                  options={bookings.map((b) => ({
                    value: b.id,
                    label: `${b.customer_name || ""} · ${b.car_name || ""} · المتبقي ${money(Math.max(0, Number(b.total_amount || 0) - Number(b.paid_amount || 0)))}`,
                  }))}
                  required
                />
                <Field
                  label="مبلغ الدفعة"
                  type="number"
                  value={data.amount || ""}
                  onChange={(v) => update("amount", v)}
                  required
                />
                <SelectField
                  label="طريقة الدفع"
                  value={data.method || "cash"}
                  onChange={(v) => update("method", v)}
                  options={[
                    { value: "cash", label: "نقداً" },
                    { value: "card", label: "بطاقة" },
                    { value: "transfer", label: "تحويل بنكي" },
                    { value: "other", label: "أخرى" },
                  ]}
                />
                <Field
                  label="تاريخ الدفعة"
                  type="date"
                  value={data.payment_date || new Date().toISOString().slice(0, 10)}
                  onChange={(v) => update("payment_date", v)}
                  required
                />
                <Field
                  label="رقم المرجع"
                  value={data.reference || ""}
                  onChange={(v) => update("reference", v)}
                />
                <div className="span-2">
                  <Field
                    label="ملاحظات"
                    value={data.notes || ""}
                    onChange={(v) => update("notes", v)}
                  />
                </div>
                <p className="form-hint span-2">
                  يتم تحديث رصيد الحجز داخل قاعدة البيانات داخل العملية نفسها عبر `record_booking_payment`.
                </p>
              </>
            )}
            {type === "expenses" && (
              <>
                <Field
                  label="وصف المصروف"
                  value={data.title || ""}
                  onChange={(v) => update("title", v)}
                  required
                />
                <SelectField
                  label="الفئة"
                  value={data.category || "other"}
                  onChange={(v) => update("category", v)}
                  options={[
                    { value: "maintenance", label: "الصيانة" },
                    { value: "insurance", label: "التأمين" },
                    { value: "fuel", label: "الوقود" },
                    { value: "tax", label: "الضرائب" },
                    { value: "loan", label: "قسط قرض" },
                    { value: "other", label: "أخرى" },
                  ]}
                />
                <Field
                  label="المبلغ (درهم)"
                  type="number"
                  value={data.amount || ""}
                  onChange={(v) => update("amount", v)}
                  required
                />
                <Field
                  label="التاريخ"
                  type="date"
                  value={data.date || new Date().toISOString().slice(0, 10)}
                  onChange={(v) => update("date", v)}
                  required
                />
                <Field
                  label="السيارة (اختياري)"
                  value={data.car_name || ""}
                  onChange={(v) => update("car_name", v)}
                />
                <Field
                  label="المستفيد أو المورد"
                  value={data.vendor || ""}
                  onChange={(v) => update("vendor", v)}
                />
              </>
            )}
            {type === "loans" && (
              <>
                <Field
                  label="المؤسسة الممولة"
                  value={data.lender || ""}
                  onChange={(v) => update("lender", v)}
                  required
                />
                <Field
                  label="السيارة"
                  value={data.car_name || ""}
                  onChange={(v) => update("car_name", v)}
                  required
                />
                <Field
                  label="أصل القرض"
                  type="number"
                  value={data.principal || ""}
                  onChange={(v) => update("principal", v)}
                  required
                />
                <Field
                  label="مبلغ الفائدة الإجمالي"
                  type="number"
                  value={data.total_interest || ""}
                  onChange={(v) => update("total_interest", v)}
                />
                <Field
                  label="القسط الشهري"
                  type="number"
                  value={data.monthly_payment || ""}
                  onChange={(v) => update("monthly_payment", v)}
                  required
                />
                <Field
                  label="الرصيد المتبقي"
                  type="number"
                  value={data.remaining_balance || ""}
                  onChange={(v) => update("remaining_balance", v)}
                  required
                />
                <Field
                  label="تاريخ بداية القرض"
                  type="date"
                  value={data.start_date || ""}
                  onChange={(v) => update("start_date", v)}
                />
                <Field
                  label="تاريخ الاستحقاق القادم"
                  type="date"
                  value={data.next_due_date || ""}
                  onChange={(v) => update("next_due_date", v)}
                />
                <Field
                  label="عدد الأشهر"
                  type="number"
                  value={data.term_months || ""}
                  onChange={(v) => update("term_months", v)}
                />
              </>
            )}
            {type === "maintenance" && (
              <>
                <Field
                  label="السيارة"
                  value={data.car_name || ""}
                  onChange={(v) => update("car_name", v)}
                  required
                />
                <Field
                  label="نوع العمل"
                  value={data.title || ""}
                  onChange={(v) => update("title", v)}
                  required
                />
                <SelectField
                  label="الحالة"
                  value={data.status || "scheduled"}
                  onChange={(v) => update("status", v)}
                  options={[
                    { value: "scheduled", label: "مبرمجة" },
                    { value: "in_progress", label: "قيد الإنجاز" },
                    { value: "completed", label: "مكتملة" },
                  ]}
                />
                <Field
                  label="التكلفة المتوقعة"
                  type="number"
                  value={data.cost || ""}
                  onChange={(v) => update("cost", v)}
                />
                <Field
                  label="تاريخ الموعد"
                  type="date"
                  value={data.due_date || ""}
                  onChange={(v) => update("due_date", v)}
                />
                <div className="span-2">
                  <Field
                    label="ملاحظات"
                    value={data.notes || ""}
                    onChange={(v) => update("notes", v)}
                  />
                </div>
                <p className="form-hint span-2">
                  واجهة إدخال تجريبية؛ يلزم ربط هذا النموذج بجدول
                  maintenance_records عند تفعيل إدارة الصيانة.
                </p>
              </>
            )}
          </div>
        </div>
        <div className="modal-actions">
          <button type="button" className="outline-btn" onClick={close}>
            إلغاء
          </button>
          <button className="primary-btn" type="submit">
            <CheckCircle2 size={17} />
            حفظ السجل
          </button>
        </div>
      </form>
    </div>
  );
}
function BrandMarquee({ logos = [], label = "علامات السيارات العالمية" }) {
  const [brokenLogos, setBrokenLogos] = useState({});
  const defaults = [
    "MERCEDES-BENZ",
    "BMW",
    "AUDI",
    "PORSCHE",
    "TOYOTA",
    "VOLKSWAGEN",
    "RENAULT",
    "LAND ROVER",
  ];
  const items = logos.length ? logos : defaults.map((name) => ({ name }));
  return (
    <div className="brand-marquee" aria-label={label}>
      <div className="brand-marquee-track">
        {[...items, ...items].map((item, i) => (
          <div
            className="brand-marquee-item"
            key={(item.path || item.name || "brand") + "-" + i}
          >
            {item.url && !brokenLogos[item.url] ? (
              <img
                src={item.url}
                alt={item.name || "شعار سيارة"}
                loading="eager"
                decoding="async"
                onError={() => setBrokenLogos((old) => ({ ...old, [item.url]: true }))}
              />
            ) : (
              <span>{item.name || "علامة سيارات"}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function Landing() {
  const [cars, setCars] = useState([]),
    [logos, setLogos] = useState([]),
    [lang, setLang] = useState("ar"),
    [site, setSite] = useState(defaultSiteSettings),
    [loading, setLoading] = useState(!!supabase),
    [error, setError] = useState(""),
    [syncedAt, setSyncedAt] = useState(null),
    [brokenImages, setBrokenImages] = useState({}),
    [bookingCar, setBookingCar] = useState(null),
    [bookingDetails, setBookingDetails] = useState({ fullName: "", phone: "", startDate: "", endDate: "", notes: "" });
  const copy = {
    ar: {
      cars: "السيارات",
      why: "لماذا نحن",
      contact: "اتصل بنا",
      admin: "دخول الإدارة",
      tag: "تجربة كراء أكثر سهولة",
      title: "استأجر سيارتك بسهولة وبأفضل الأسعار",
      subtitle: "تجربة قيادة مريحة وموثوقة. اختر سيارتك وأرسل طلب الحجز.",
      discover: "اكتشف السيارات",
      whatsapp: "تواصل عبر واتساب",
      available: "سيارات متاحة",
      service: "خدمة العملاء",
      prices: "وضوح في الأسعار",
      fleet: "أسطولنا",
      choose: "اختر السيارة المناسبة لرحلتك",
      fleetText: "تعرّف على السيارات المتاحة واطلب حجزك بسهولة.",
      day: "لليوم",
      book: "اطلب الحجز",
      confirmPlate: "تأكيد رقم التسجيل عند الحجز",
      none: "لا توجد سيارات متاحة حالياً.",
      whyTitle: "تجربة كراء واضحة من البداية",
      trust: "وضوح وثقة",
      trustText: "شروط وأسعار واضحة قبل تأكيد الحجز.",
      booking: "حجز منظم",
      bookingText: "تواصل سريع لتأكيد التواريخ والتوفر.",
      choice: "اختيارات متنوعة",
      choiceText: "أسطول قابل للتوسع حسب احتياجاتك.",
      footer: "رحلتك تبدأ باختيار السيارة المناسبة.",
      rights: "جميع الحقوق محفوظة.",
      logos: "علامات السيارات العالمية",
      loading: "جارٍ تحميل بيانات الوكالة…",
      error: "تعذر تحميل بيانات الموقع. حاول تحديث الصفحة.",
      retry: "إعادة التحميل",
      email: "البريد الإلكتروني",
      address: "العنوان",
      call: "اتصال",
      bookingTitle: "تأكيد طلب الحجز",
      bookingIntro: "أدخل بياناتك لمراجعة تفاصيل الطلب قبل الانتقال إلى واتساب.",
      fullName: "الاسم الكامل",
      phoneNumber: "رقم الهاتف",
      startDate: "تاريخ بداية الكراء",
      endDate: "تاريخ نهاية الكراء",
      notesLabel: "ملاحظات إضافية (اختياري)",
      estimate: "السعر التقديري",
      days: "عدد الأيام",
      cancel: "إلغاء",
      continueWhatsapp: "مراجعة الطلب عبر واتساب",
      requiredFields: "يرجى إدخال الاسم ورقم الهاتف وتاريخي الكراء بشكل صحيح.",
      invalidDates: "تاريخ النهاية يجب أن يكون بعد تاريخ البداية.",
      requestSummary: "ملخص طلب الحجز",
      selectedCar: "السيارة",
      totalEstimate: "المجموع التقديري",
    },
    fr: {
      cars: "Voitures",
      why: "Pourquoi nous",
      contact: "Contact",
      admin: "Espace admin",
      tag: "La location en toute simplicité",
      title: "Louez votre voiture facilement, au meilleur prix",
      subtitle: "Une conduite confortable et fiable. Choisissez votre voiture et demandez une réservation.",
      discover: "Découvrir les voitures",
      whatsapp: "Contacter sur WhatsApp",
      available: "Voitures disponibles",
      service: "Service client",
      prices: "Tarifs transparents",
      fleet: "Notre flotte",
      choose: "Choisissez la voiture idéale pour votre trajet",
      fleetText: "Découvrez les véhicules disponibles et demandez votre réservation.",
      day: "par jour",
      book: "Réserver",
      confirmPlate: "Immatriculation confirmée lors de la réservation",
      none: "Aucun véhicule disponible pour le moment.",
      whyTitle: "Une location claire dès le départ",
      trust: "Transparence et confiance",
      trustText: "Des conditions et des prix clairs avant confirmation.",
      booking: "Réservation organisée",
      bookingText: "Un contact rapide pour confirmer les dates et la disponibilité.",
      choice: "Un choix varié",
      choiceText: "Une flotte évolutive selon vos besoins.",
      footer: "Votre voyage commence par le bon choix.",
      rights: "Tous droits réservés.",
      logos: "Marques automobiles internationales",
      loading: "Chargement des données de l’agence…",
      error: "Impossible de charger les données. Veuillez actualiser la page.",
      retry: "Actualiser",
      email: "E-mail",
      address: "Adresse",
      call: "Appeler",
      bookingTitle: "Confirmer la demande de réservation",
      bookingIntro: "Renseignez vos informations pour vérifier le récapitulatif avant WhatsApp.",
      fullName: "Nom complet",
      phoneNumber: "Téléphone",
      startDate: "Début de location",
      endDate: "Fin de location",
      notesLabel: "Remarques (facultatif)",
      estimate: "Prix estimé",
      days: "Nombre de jours",
      cancel: "Annuler",
      continueWhatsapp: "Vérifier la demande sur WhatsApp",
      requiredFields: "Veuillez saisir le nom, le téléphone et des dates valides.",
      invalidDates: "La date de fin doit être postérieure à la date de début.",
      requestSummary: "Récapitulatif de la réservation",
      selectedCar: "Voiture",
      totalEstimate: "Total estimé",
    },
    en: {
      cars: "Cars",
      why: "Why us",
      contact: "Contact",
      admin: "Admin login",
      tag: "Car rental made simple",
      title: "Rent your car easily at the best prices",
      subtitle: "Enjoy a comfortable, reliable drive. Choose your car and request a booking.",
      discover: "Explore cars",
      whatsapp: "Contact on WhatsApp",
      available: "Cars available",
      service: "Customer service",
      prices: "Transparent pricing",
      fleet: "Our fleet",
      choose: "Choose the right car for your journey",
      fleetText: "Explore available vehicles and request your booking with ease.",
      day: "per day",
      book: "Request booking",
      confirmPlate: "Registration confirmed when booking",
      none: "No cars are currently available.",
      whyTitle: "Clear rental experience from the start",
      trust: "Clarity and trust",
      trustText: "Clear terms and pricing before confirmation.",
      booking: "Easy booking",
      bookingText: "Quick contact to confirm dates and availability.",
      choice: "More choices",
      choiceText: "A fleet that can grow with your needs.",
      footer: "Your journey starts with the right car.",
      rights: "All rights reserved.",
      logos: "Global automotive brands",
      loading: "Loading agency data…",
      error: "Unable to load website data. Please refresh the page.",
      retry: "Refresh",
      email: "Email",
      address: "Address",
      call: "Call",
      bookingTitle: "Confirm booking request",
      bookingIntro: "Enter your details and review the request before continuing to WhatsApp.",
      fullName: "Full name",
      phoneNumber: "Phone number",
      startDate: "Rental start date",
      endDate: "Rental end date",
      notesLabel: "Additional notes (optional)",
      estimate: "Estimated price",
      days: "Number of days",
      cancel: "Cancel",
      continueWhatsapp: "Review request on WhatsApp",
      requiredFields: "Enter your name, phone number, and valid rental dates.",
      invalidDates: "The end date must be after the start date.",
      requestSummary: "Booking request summary",
      selectedCar: "Car",
      totalEstimate: "Estimated total",
    },
  };
  const t = copy[lang];
  const refreshPublic = async () => {
    if (!supabase) {
      setLoading(false);
      setError("");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const [carsResult, settings, logoSection] = await Promise.all([
        supabase.from("cars").select("*").eq("status", "available"),
        supabase.from("site_settings").select("*").eq("id", 1).maybeSingle(),
        supabase.from("site_sections").select("settings").eq("section_key", "brand_logos").eq("is_visible", true).maybeSingle(),
      ]);
      if (carsResult.error) throw carsResult.error;
      if (settings.error) throw settings.error;
      setCars(carsResult.data || []);
      setSite(normalizeSettings(settings.data || {}));
      const savedLogos = Array.isArray(logoSection.data?.settings?.logos)
        ? logoSection.data.settings.logos
            .map((logo) => normalizeBrandLogo(logo, supabase))
            .filter((logo) => logo && (logo.url || logo.path || logo.name))
        : [];
      setLogos(savedLogos);
      setSyncedAt(new Date());
    } catch (err) {
      console.error("public site sync", err);
      setError(err.message || t.error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    refreshPublic();
    const onFocus = () => refreshPublic();
    const onVisible = () => {
      if (document.visibilityState === "visible") refreshPublic();
    };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);
  useEffect(() => {
    document.title = site.brand || "Elite Drive";
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", site.hero_subtitle || t.subtitle);
  }, [site.brand, site.hero_subtitle, t.subtitle]);
  const whatsapp = normalizePhone(site.whatsapp);
  const phone = normalizePhone(site.contact_phone || site.whatsapp);
  const heroStyle = site.hero_image
    ? { backgroundImage: `linear-gradient(90deg,rgba(5,6,8,.91),rgba(5,6,8,.36)),url('${site.hero_image}')` }
    : { backgroundImage: "linear-gradient(135deg,#0a0b0f,#1e2028 60%,#111318)" };
  const localizedHeroTitle = lang !== "ar" && /[\u0600-\u06FF]/.test(site.hero_title || "")
    ? t.title
    : (site.hero_title || t.title);
  const localizedHeroSubtitle = lang !== "ar" && /[\u0600-\u06FF]/.test(site.hero_subtitle || "")
    ? t.subtitle
    : (site.hero_subtitle || t.subtitle);
  const todayDate = new Date();
  const todayISO = `${todayDate.getFullYear()}-${String(todayDate.getMonth() + 1).padStart(2, "0")}-${String(todayDate.getDate()).padStart(2, "0")}`;
  const rentalDays = bookingDetails.startDate && bookingDetails.endDate
    ? Math.max(0, Math.ceil((new Date(bookingDetails.endDate + "T00:00:00") - new Date(bookingDetails.startDate + "T00:00:00")) / 86400000))
    : 0;
  const bookingEstimate = bookingCar ? rentalDays * Number(bookingCar.daily_rate || 0) : 0;
  const openBooking = (car) => {
    setBookingCar(car);
    setBookingDetails({ fullName: "", phone: "", startDate: todayISO, endDate: "", notes: "" });
  };
  const sendBookingToWhatsApp = (event) => {
    event.preventDefault();
    if (!bookingCar || !bookingDetails.fullName.trim() || !normalizePhone(bookingDetails.phone, "") || !bookingDetails.startDate || !bookingDetails.endDate) {
      window.alert(t.requiredFields);
      return;
    }
    if (bookingDetails.endDate <= bookingDetails.startDate) {
      window.alert(t.invalidDates);
      return;
    }
    const lines = lang === "fr"
      ? [`Bonjour, je souhaite réserver une voiture.`, `${t.selectedCar}: ${bookingCar.name}`, `${t.fullName}: ${bookingDetails.fullName.trim()}`, `${t.phoneNumber}: ${bookingDetails.phone}`, `${t.startDate}: ${bookingDetails.startDate}`, `${t.endDate}: ${bookingDetails.endDate}`, `${t.days}: ${rentalDays}`, `${t.estimate}: ${money(bookingEstimate)}`, bookingDetails.notes ? `${t.notesLabel}: ${bookingDetails.notes}` : ""]
      : lang === "en"
        ? [`Hello, I would like to request a car booking.`, `${t.selectedCar}: ${bookingCar.name}`, `${t.fullName}: ${bookingDetails.fullName.trim()}`, `${t.phoneNumber}: ${bookingDetails.phone}`, `${t.startDate}: ${bookingDetails.startDate}`, `${t.endDate}: ${bookingDetails.endDate}`, `${t.days}: ${rentalDays}`, `${t.estimate}: ${money(bookingEstimate)}`, bookingDetails.notes ? `${t.notesLabel}: ${bookingDetails.notes}` : ""]
        : [`السلام عليكم، أود طلب حجز سيارة.`, `${t.selectedCar}: ${bookingCar.name}`, `${t.fullName}: ${bookingDetails.fullName.trim()}`, `${t.phoneNumber}: ${bookingDetails.phone}`, `${t.startDate}: ${bookingDetails.startDate}`, `${t.endDate}: ${bookingDetails.endDate}`, `${t.days}: ${rentalDays}`, `${t.estimate}: ${money(bookingEstimate)}`, bookingDetails.notes ? `${t.notesLabel}: ${bookingDetails.notes}` : ""];
    const target = `https://wa.me/${whatsapp}?text=${encodeURIComponent(lines.filter(Boolean).join("\n"))}`;
    window.open(target, "_blank", "noopener,noreferrer");
    setBookingCar(null);
  };
  const BrandLogo = ({ className = "" }) => (
    <Link to="/" className={"landing-brand " + className}>
      <span>
        <CarFront />
      </span>
      <b>{site.brand || "Elite Drive"}</b>
    </Link>
  );
  const publicCarImage = (car) => car.image_url || car.hero_image || "";
  return (
    <div className="landing" dir={lang === "ar" ? "rtl" : "ltr"} lang={lang}>
      <nav className="landing-nav">
        <BrandLogo />
        <div className="landing-nav-links">
          <a href="#cars">{t.cars}</a>
          <a href="#benefits">{t.why}</a>
          <a href="#contact">{t.contact}</a>
          <Link className="admin-link" to="/admin">
            {t.admin} <ArrowUpLeft size={15} />
          </Link>
          <div className="language-switch" aria-label="Language">
            <button className={lang === "ar" ? "selected" : ""} onClick={() => setLang("ar")}>ع</button>
            <button className={lang === "fr" ? "selected" : ""} onClick={() => setLang("fr")}>FR</button>
            <button className={lang === "en" ? "selected" : ""} onClick={() => setLang("en")}>EN</button>
          </div>
        </div>
      </nav>
      {loading && <div className="public-sync-banner">{t.loading}</div>}
      {error && (
        <div className="public-sync-banner error">
          <span>{error}</span>
          <button onClick={refreshPublic}>{t.retry}</button>
        </div>
      )}
      <section className="landing-hero" style={heroStyle}>
        <div className="hero-content">
          <span className="hero-tag"><i /> {t.tag}</span>
          <h1>{localizedHeroTitle}</h1>
          <p>{localizedHeroSubtitle}</p>
          <div className="hero-buttons">
            <a className="primary-btn" href="#cars">
              {t.discover} <ArrowUpLeft size={17} />
            </a>
            <a className="outline-btn" href={`https://wa.me/${whatsapp}`} target="_blank" rel="noreferrer">
              {t.whatsapp} <Phone size={16} />
            </a>
          </div>
          <div className="landing-kpis">
            <div><b>{cars.length}</b><small>{t.available}</small></div>
            <div><b>24/7</b><small>{t.service}</small></div>
            <div><b>100%</b><small>{t.prices}</small></div>
          </div>
          {syncedAt && (
            <small className="public-sync-time">
              {syncedAt.toLocaleString(lang === "ar" ? "ar-MA" : lang === "fr" ? "fr-FR" : "en-US")}
            </small>
          )}
        </div>
        <BrandMarquee logos={logos} label={t.logos} />
      </section>
      <section id="cars" className="landing-cars">
        <div className="landing-section-head">
          <span>{t.fleet}</span>
          <h2>{t.choose}</h2>
          <p>{t.fleetText}</p>
        </div>
        <div className="public-cars">
          {cars.map((car) => {
            const src = publicCarImage(car);
            return (
              <article className="public-car" key={car.id}>
                {src && !brokenImages[car.id] ? (
                  <img
                    src={src}
                    alt={car.name}
                    loading="lazy"
                    onError={() => setBrokenImages((old) => ({ ...old, [car.id]: true }))}
                  />
                ) : (
                  <div className="car-image-fallback"><CarFront size={32} /></div>
                )}
                <div>
                  <span className="public-category">{car.category || t.cars}</span>
                  <h3>{car.name}</h3>
                  <p>{car.year || ""} · {car.plate || t.confirmPlate}</p>
                  <div className="public-price">
                    <b>{money(car.daily_rate)}</b>
                    <small>{t.day}</small>
                  </div>
                  <button type="button" className="public-book-btn" onClick={() => openBooking(car)}>
                    {t.book} <ArrowUpLeft size={15} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
        {!loading && cars.length === 0 && <p className="empty">{t.none}</p>}
      </section>
      <section className="landing-benefits" id="benefits">
        <div>
          <span>{site.brand || "Elite Drive"}</span>
          <h2>{t.whyTitle}</h2>
        </div>
        <div className="benefits-grid">
          <div><ShieldCheck /><b>{t.trust}</b><p>{t.trustText}</p></div>
          <div><CalendarDays /><b>{t.booking}</b><p>{t.bookingText}</p></div>
          <div><CarFront /><b>{t.choice}</b><p>{t.choiceText}</p></div>
        </div>
      </section>
      <footer id="contact" className="landing-footer">
        <BrandLogo className="footer-brand" />
        <p>{site.address || site.city || t.footer}</p>
        <div className="footer-contact-grid">
          <a href={`https://wa.me/${whatsapp}`} target="_blank" rel="noreferrer">
            <Phone size={15} /> {site.whatsapp ? "+" + whatsapp : t.whatsapp}
          </a>
          {site.contact_phone && (
            <a href={`tel:+${phone}`}>
              <Phone size={15} /> {t.call}: +{phone}
            </a>
          )}
          {site.contact_email && (
            <a href={`mailto:${site.contact_email}`}>
              <Globe size={15} /> {site.contact_email}
            </a>
          )}
        </div>
        <small>
          © {new Date().getFullYear()} {site.brand || "Elite Drive"}. {t.rights}
        </small>
      </footer>
      {bookingCar && (
        <div className="modal-backdrop booking-request-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setBookingCar(null); }}>
          <form className="modal booking-request-modal" onSubmit={sendBookingToWhatsApp} dir={lang === "ar" ? "rtl" : "ltr"} lang={lang}>
            <div className="modal-head">
              <div>
                <span className="booking-modal-kicker">Elite Drive</span>
                <h2>{t.bookingTitle}</h2>
                <p>{t.bookingIntro}</p>
              </div>
              <button type="button" className="icon-btn" aria-label={t.cancel} onClick={() => setBookingCar(null)}>×</button>
            </div>
            <div className="booking-request-body">
              <div className="booking-car-summary">
                {publicCarImage(bookingCar) && <img src={publicCarImage(bookingCar)} alt={bookingCar.name} />}
                <div><small>{t.selectedCar}</small><strong>{bookingCar.name}</strong><span>{money(bookingCar.daily_rate)} / {t.day}</span></div>
              </div>
              <div className="booking-request-grid">
                <label>{t.fullName}<input required autoComplete="name" value={bookingDetails.fullName} onChange={(e) => setBookingDetails({ ...bookingDetails, fullName: e.target.value })} placeholder={t.fullName} /></label>
                <label>{t.phoneNumber}<input required type="tel" autoComplete="tel" value={bookingDetails.phone} onChange={(e) => setBookingDetails({ ...bookingDetails, phone: e.target.value })} placeholder="06XXXXXXXX" /></label>
                <label>{t.startDate}<input required type="date" min={todayISO} value={bookingDetails.startDate} onChange={(e) => setBookingDetails({ ...bookingDetails, startDate: e.target.value, endDate: bookingDetails.endDate && bookingDetails.endDate <= e.target.value ? "" : bookingDetails.endDate })} /></label>
                <label>{t.endDate}<input required type="date" min={bookingDetails.startDate || todayISO} value={bookingDetails.endDate} onChange={(e) => setBookingDetails({ ...bookingDetails, endDate: e.target.value })} /></label>
                <label className="booking-notes-field">{t.notesLabel}<textarea rows="2" value={bookingDetails.notes} onChange={(e) => setBookingDetails({ ...bookingDetails, notes: e.target.value })} placeholder={t.notesLabel} /></label>
              </div>
              <div className="booking-estimate-panel">
                <span>{t.days}: <strong>{rentalDays}</strong></span>
                <span>{t.totalEstimate}: <strong>{money(bookingEstimate)}</strong></span>
              </div>
              <p className="booking-estimate-note">{lang === "ar" ? "هذا تقدير أولي؛ سيتم تأكيد التوفر والسعر النهائي عبر واتساب." : lang === "fr" ? "Estimation indicative ; disponibilité et prix final seront confirmés sur WhatsApp." : "This is an estimate; availability and final price will be confirmed on WhatsApp."}</p>
            </div>
            <div className="modal-actions booking-request-actions">
              <button type="button" className="outline-btn" onClick={() => setBookingCar(null)}>{t.cancel}</button>
              <button type="submit" className="primary-btn" disabled={!whatsapp || rentalDays < 1}><Phone size={16} /> {t.continueWhatsapp}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
function Root() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/admin/*" element={<App />} />
    </Routes>
  );
}

createRoot(document.getElementById("root")).render(
  <BrowserRouter basename={import.meta.env.BASE_URL}>
    <Root />
  </BrowserRouter>,
);
