# Elite Drive

واجهة عربية متجاوبة مبنية باستخدام React وVite مع تكامل Supabase.

## النشر إلى GitHub Pages دون Secrets

1. أنشئ مستودع GitHub بفرع `main`.
2. ارفع ملف ZIP الخاص بالمشروع إلى جذر المستودع.
3. تأكد من وجود `.github/workflows/deploy-pages.yml` في المستودع نفسه (ارفع مجلد `.github` أيضاً إذا لم يكن ضمن ZIP).
4. من `Settings → Pages` اختر `GitHub Actions` كمصدر للنشر.
5. افتح تبويب `Actions` وشغّل workflow باسم `Build ZIP and deploy Elite Drive to GitHub Pages`، أو ادفع تغييراً جديداً.
6. بعد نجاح المهمة، افتح رابط Pages الظاهر في سجل النشر.

## تنبيه أمني

يستخدم Workflow عنوان Supabase ومفتاح `sb_publishable` مباشرة في الملف، لذلك لا حاجة إلى GitHub Secrets/Variables. مفاتيح publishable مخصصة للواجهة الأمامية وستكون مرئية للزوار في كود الموقع؛ لا تضع أبداً `service_role` أو أي secret key هنا. يجب أن تكون سياسات RLS صحيحة، وألا تسمح سياسات قاعدة البيانات بالوصول غير المصرح به.

## تشغيل محلياً

```bash
npm install
npm run dev
```

## البناء

```bash
npm run build
```


## GitHub Pages routing fix

`BrowserRouter` uses Vite's `import.meta.env.BASE_URL` as its basename, so routes work when deployed under a repository path such as `/Location/`.
