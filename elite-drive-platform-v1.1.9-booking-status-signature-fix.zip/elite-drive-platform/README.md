# Elite Drive

منصة وكالة كراء سيارات مبنية بـ React وVite وSupabase، وتُنشر على GitHub Pages.

## التشغيل المحلي

```bash
npm ci
npm test
npm run build
npm run dev
```

## متغيرات البيئة

أنشئ ملف `.env` محلياً ولا ترفعه إلى GitHub:

```bash
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

لا تضع `service_role key` أو أي سر آخر في الواجهة.

## تطبيق ترقية قاعدة البيانات

نفّذ الملف التالي مرة واحدة في Supabase SQL Editor:

```text
supabase/upgrade_2026_10_22.sql
```

إذا كانت صلاحيات قراءة الإعدادات العامة غير مفعلة بعد، نفّذ أيضاً:

```text
supabase/fix_landing_page_public_read.sql
```

## النشر على GitHub Pages

1. ارفع محتويات جذر المشروع فقط إلى المستودع.
2. أضف القيم العامة في GitHub Repository Variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. فعّل GitHub Pages عبر GitHub Actions.
4. workflow موجود في `.github/workflows/deploy-pages.yml`.
5. عند كل دمج إلى `main` سيتم:
   - تثبيت الاعتماديات من `package-lock.json`.
   - تشغيل الاختبارات.
   - تشغيل البناء.
   - نشر مجلد `dist`.

## النسخ الاحتياطي والاستعادة

من داخل الإدارة افتح **إدارة البيانات**:

- إنشاء نسخة JSON وتنزيلها.
- التحقق من ملف نسخة قبل الاستعادة.
- الاستعادة بنمط دمج آمن.
- تصفير إعدادات الموقع منفصلاً.
- تصفير البيانات التشغيلية بعد تأكيد صريح.

ملف JSON يحتوي مراجع الملفات والروابط، ولا يحتوي ملفات Supabase Storage الثنائية نفسها.

## ملاحظات أمنية

- RLS مفعّل ولا يتم تعطيله لتجاوز الأخطاء.
- إدارة الشعارات والمدفوعات والبيانات تعتمد على الأدوار الفعلية في `profiles`.
- المستندات الخاصة بالعقود والوصولات تُحفظ في buckets خاصة.
- سجل التدقيق الحساس يُنشأ من PostgreSQL ولا يقبل إدخالاً مباشراً من العميل.

## الاختبارات المنفذة في هذه البيئة

- `npm test`: 6 اختبارات منطقية ناجحة.
- `npm run build`: بناء Vite ناجح.
- `npm audit --omit=dev`: 0 ثغرات معروفة في اعتماديات الإنتاج.

لم يتم اختبار تسجيل الدخول أو الكتابة إلى مشروع Supabase الإنتاجي لعدم توفر بيانات اعتماد اختبارية داخل بيئة العمل.

## Public booking form (v1.1.4)

Before deploying this version, open **Supabase Dashboard → SQL Editor**, paste and run `supabase/public_booking_rpc.sql` once. This creates a restricted `SECURITY DEFINER` RPC for the public form; the website does not receive direct write access to the customers or bookings tables. Public booking requests are stored as `pending`, using the selected car's current daily rate, then WhatsApp opens with the request number and details. A request is not sent to WhatsApp if the database save fails or the selected dates overlap another pending/confirmed/active booking.
