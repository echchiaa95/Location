
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeSettings,
  normalizePhone,
  verifySettings,
  bookingDays,
  buildBookingPricing,
  buildMonthlyFinancials,
  buildOperationalBackup,
  validateBackup,
} from '../src/platform.js';

test('normalizePhone converts Moroccan local mobile numbers', () => {
  assert.equal(normalizePhone('0612-345-678'), '212612345678');
  assert.equal(normalizePhone('00212612345678'), '212612345678');
  assert.equal(normalizePhone(''), '212600000000');
});

test('normalizeSettings keeps only supported canonical fields', () => {
  const row = normalizeSettings({ brand: '  Elite Drive Agadir  ', whatsapp: '0612345678', accent: '#12AB34', malicious: true });
  assert.equal(row.brand, 'Elite Drive Agadir');
  assert.equal(row.whatsapp, '212612345678');
  assert.equal(row.accent, '#12AB34');
  assert.equal('malicious' in row, false);
});

test('verifySettings detects field mismatch', () => {
  const result = verifySettings({ brand: 'A', hero_title: 'X' }, { brand: 'B', hero_title: 'X' });
  assert.equal(result.ok, false);
  assert.deepEqual(result.mismatches, ['brand']);
});

test('booking pricing calculates daily total and fallback', () => {
  const cars = [{ id: 'car-1', daily_rate: 300 }];
  const pricing = buildBookingPricing({ car_id: 'car-1', start_date: '2026-10-01', end_date: '2026-10-04' }, cars);
  assert.equal(pricing.daily_rate, 300);
  assert.equal(pricing.total_amount, 900);
  assert.equal(bookingDays('2026-10-01', '2026-10-04'), 3);
});

test('monthly financials aggregate income and expenses by month', () => {
  const data = buildMonthlyFinancials(
    [{ payment_date: '2026-10-02', amount: 500 }, { payment_date: '2026-10-03', amount: 100, direction: 'refund' }],
    [{ expense_date: '2026-10-04', amount: 150 }],
    1,
  );
  assert.equal(data.length, 1);
  assert.equal(data[0].revenue, 400);
  assert.equal(data[0].cost, 150);
});

test('backup payload validates and preserves table list', () => {
  const payload = buildOperationalBackup({ cars: [{ id: '1' }] });
  assert.equal(payload.version, 1);
  assert.equal(payload.includesStorageFiles, false);
  const validation = validateBackup(payload);
  assert.equal(validation.ok, true);
  assert.equal(payload.tables.cars.length, 1);
});
