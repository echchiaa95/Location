-- Allow the public landing page to read its saved settings.
-- Keep writes restricted to authenticated authorized managers.
BEGIN;
GRANT SELECT ON TABLE public.site_settings TO anon, authenticated;
GRANT INSERT, UPDATE ON TABLE public.site_settings TO authenticated;
DROP POLICY IF EXISTS site_settings_public_read ON public.site_settings;
CREATE POLICY site_settings_public_read
ON public.site_settings
FOR SELECT
TO anon, authenticated
USING (true);

GRANT SELECT ON TABLE public.site_sections TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON TABLE public.site_sections TO authenticated;
DROP POLICY IF EXISTS site_sections_public_read ON public.site_sections;
CREATE POLICY site_sections_public_read
ON public.site_sections
FOR SELECT
TO anon, authenticated
USING (
  is_visible = true
  OR public.has_role(ARRAY['owner','admin','manager']::text[])
);
COMMIT;
