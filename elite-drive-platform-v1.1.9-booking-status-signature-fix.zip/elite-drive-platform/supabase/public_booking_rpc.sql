-- Public website booking requests. Run once in Supabase SQL Editor.
-- Creates/uses a customer and saves a pending booking atomically before WhatsApp opens.
create or replace function public.public_create_booking(
  p_car_id uuid,
  p_full_name text,
  p_phone text,
  p_start_date date,
  p_end_date date,
  p_notes text default ''
)
returns table (booking_id uuid, booking_number bigint)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_customer_id uuid;
  v_booking_id uuid;
  v_booking_number bigint;
  v_phone text;
  v_name text;
  v_daily_rate numeric(12,2);
  v_car_name text;
begin
  v_name := trim(coalesce(p_full_name, ''));
  v_phone := regexp_replace(coalesce(p_phone, ''), '[^0-9+]', '', 'g');

  if length(v_name) < 2 then
    raise exception 'اسم العميل مطلوب.' using errcode = '22023';
  end if;
  if length(regexp_replace(v_phone, '[^0-9]', '', 'g')) < 8 then
    raise exception 'رقم الهاتف غير صالح.' using errcode = '22023';
  end if;
  if p_start_date is null or p_end_date is null or p_start_date < current_date or p_end_date <= p_start_date then
    raise exception 'تواريخ الحجز غير صالحة.' using errcode = '22023';
  end if;

  select c.daily_rate, c.name
    into v_daily_rate, v_car_name
    from public.cars c
   where c.id = p_car_id and c.status = 'available'
   for update;
  if not found then
    raise exception 'السيارة غير متاحة حالياً.' using errcode = 'P0002';
  end if;

  if exists (
    select 1 from public.bookings b
     where b.car_id = p_car_id
       and b.status in ('pending','confirmed','active')
       and daterange(b.start_date, b.end_date, '[)') && daterange(p_start_date, p_end_date, '[)')
  ) then
    raise exception 'هذه السيارة لديها حجز متداخل في التواريخ المحددة.' using errcode = '23P01';
  end if;

  select c.id into v_customer_id
    from public.customers c
   where regexp_replace(coalesce(c.phone, ''), '[^0-9]', '', 'g') = regexp_replace(v_phone, '[^0-9]', '', 'g')
   order by c.created_at desc
   limit 1;

  if v_customer_id is null then
    insert into public.customers (full_name, phone, notes)
    values (v_name, v_phone, 'تم التسجيل من نموذج الحجز بالموقع العام')
    returning id into v_customer_id;
  else
    update public.customers set full_name = v_name, updated_at = now() where id = v_customer_id;
  end if;

  insert into public.bookings (
    customer_id, car_id, start_date, end_date, daily_rate, total_amount,
    status, notes, pickup_location, return_location
  ) values (
    v_customer_id, p_car_id, p_start_date, p_end_date, v_daily_rate,
    v_daily_rate * (p_end_date - p_start_date), 'pending',
    concat_ws(E'\n', nullif(trim(coalesce(p_notes, '')), ''), 'طلب حجز من الموقع العام'),
    null, null
  ) returning bookings.id, bookings.booking_number into v_booking_id, v_booking_number;

  return query select v_booking_id, v_booking_number;
end;
$$;

revoke all on function public.public_create_booking(uuid, text, text, date, date, text) from public;
grant execute on function public.public_create_booking(uuid, text, text, date, date, text) to anon, authenticated;
