-- Elite Drive: authenticated admin profile lookup for the current session.
-- Run once in Supabase SQL Editor as project owner.
-- This function returns only the current authenticated user's profile.

create or replace function public.get_my_admin_profile()
returns table (
  user_id uuid,
  email text,
  role text,
  is_active boolean
)
language sql
stable
security definer
set search_path = ''
as $$
  select p.id, u.email::text, p.role::text, p.is_active
  from public.profiles as p
  join auth.users as u on u.id = p.id
  where p.id = (select auth.uid())
  limit 1;
$$;

revoke all on function public.get_my_admin_profile() from public;
grant execute on function public.get_my_admin_profile() to authenticated;
