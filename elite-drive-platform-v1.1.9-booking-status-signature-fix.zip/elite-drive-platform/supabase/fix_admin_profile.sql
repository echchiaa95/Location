-- Elite Drive: repair the owner profile for an existing Supabase Auth user.
-- Replace the email below with the exact email shown in Authentication > Users.
-- Run this in Supabase SQL Editor as project owner.

insert into public.profiles (id, full_name, role, is_active)
select u.id, coalesce(u.raw_user_meta_data->>'full_name', 'Elite Drive Admin'), 'owner', true
from auth.users u
where lower(u.email) = lower('REPLACE_WITH_YOUR_AUTH_EMAIL@example.com')
on conflict (id) do update
set role = 'owner', is_active = true, updated_at = now();

-- Check result: should return one row with role = owner and is_active = true.
select p.id, u.email, p.role, p.is_active
from public.profiles p
join auth.users u on u.id = p.id
where lower(u.email) = lower('REPLACE_WITH_YOUR_AUTH_EMAIL@example.com');
