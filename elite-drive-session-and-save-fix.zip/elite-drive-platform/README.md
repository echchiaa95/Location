# Elite Drive

واجهة عربية متجاوبة مبنية باستخدام React وVite مع تكامل Supabase.

## النشر إلى GitHub Pages دون Secrets

1. أنشئ مستودع GitHub بفرع `main`.
2. ارفع ملف ZIP الخاص بالمشروع إلى جذر المستودع.
3. تأكد من وجود `.github/workflows/deploy-pages.yml` في المستودع نفسه (ارفع مجلد `.github` أيضاً إذا لم يكن ضمن ZIP).
4. من `Settings → Pages` اختر `GitHub Actions` كمصدر للنشر.
5. افتح تبويب `Actions` وشغّل workflow باسم `Build ZIP and deploy Elite Drive to GitHub Pages`، أو ادفع تغييراً جديداً.
6. بعد نجاح المهمة، افتح رابط Pages الظاهر في سجل النشر.

## تنبيه أمني

يستخدم Workflow عنوان Supabase ومفتاح `sb_publishable` مباشرة في الملف، لذلك لا حاجة إلى GitHub Secrets/Variables. مفاتيح publishable مخصصة للواجهة الأمامية وستكون مرئية للزوار في كود الموقع؛ لا تضع أبداً `service_role` أو أي secret key هنا. يجب أن تكون سياسات RLS صحيحة، وألا تسمح سياسات قاعدة البيانات بالوصول غير المصرح به.

## تشغيل محلياً

```bash
npm install
npm run dev
```

## البناء

```bash
npm run build
```


## GitHub Pages routing fix

`BrowserRouter` uses Vite's `import.meta.env.BASE_URL` as its basename, so routes work when deployed under a repository path such as `/Location/`.


## تحديثات حماية لوحة الإدارة وشعارات السيارات

- مسار `/admin` يعرض صفحة تسجيل الدخول فقط عند عدم وجود جلسة معتمدة.
- لوحة الإدارة تقبل أدوار `owner` و`admin` و`manager` فقط، وتتحقق من جدول `profiles`.
- لإتاحة رفع شعارات السيارات من الهاتف، شغّل `supabase/brand_logos_storage.sql` مرة واحدة من Supabase SQL Editor. ينشئ bucket باسم `site-assets` وسياسات وصول تسمح للزوار بقراءة الصور وللمدير المعتمد بإدارتها.
- تُحفظ قائمة الشعارات في `site_sections` تحت `section_key = brand_logos`، وتظهر في شريط متحرك أسفل `DRIVE YOUR WAY`.
- بعد نشر نسخة جديدة، امسح ذاكرة التخزين المؤقت للمتصفح أو افتح الرابط في نافذة خاصة إذا لم تظهر التحديثات.


## إصلاح صلاحية المدير
إذا ظهر أن الحساب لا يملك صلاحية الإدارة، افتح `supabase/fix_admin_profile.sql` واستبدل البريد الوارد فيه ببريد المستخدم نفسه في Supabase Authentication → Users، ثم نفّذ SQL في Supabase SQL Editor. إذا ظهرت رسالة `Invalid login credentials` فراجع كلمة المرور في Authentication أو استخدم إعادة تعيين كلمة المرور؛ تعديل الدور لا يصلح كلمة مرور خاطئة.

## اللغات
صفحة الهبوط تدعم العربية والفرنسية والإنجليزية عبر أزرار اللغة في الشريط العلوي.


## Fix admin profile lookup (if login reports profile unreadable)

Run `supabase/fix_admin_profile_rpc.sql` once in the Supabase SQL Editor while signed in as the project owner. This creates `public.get_my_profile()`, a security-definer RPC that returns only the current authenticated user's role and active flag. The app uses this RPC to avoid a profile SELECT being blocked by a restrictive RLS policy. Then redeploy this ZIP using the GitHub Actions workflow.


## إصلاح تسجيل دخول المدير

هذه النسخة تستخدم الدالة `public.get_my_admin_profile()` لقراءة صلاحيات المدير ضمن جلسة Supabase المصادق عليها، بدل الاستعلام المباشر من جدول `profiles`.
1. افتح Supabase SQL Editor وشغّل `supabase/fix_admin_profile_rpc.sql`.
2. ارفع ملف ZIP هذا إلى جذر مستودع GitHub واستبدل النسخة القديمة.
3. انتظر نجاح GitHub Actions ثم افتح `/Location/admin` وأعد تحميل الصفحة.
4. سجّل الدخول بحساب Auth الحالي. لا تُنشئ حسابًا جديدًا إذا كان الملف موجودًا بالفعل.

لا تضع مفتاح `service_role` في تطبيق المتصفح.
