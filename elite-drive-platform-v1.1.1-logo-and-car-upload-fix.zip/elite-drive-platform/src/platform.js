
export const SCHEMA_VERSION = 1;
export const APP_VERSION = "1.1.0";
export const SETTINGS_COLUMNS = [
  "brand",
  "hero_title",
  "hero_subtitle",
  "hero_image",
  "whatsapp",
  "city",
  "accent",
  "logo_url",
  "contact_phone",
  "contact_email",
  "address",
  "instagram_url",
  "facebook_url",
];
export const DEFAULT_SETTINGS = Object.freeze({
  id: 1,
  brand: "Elite Drive",
  hero_title: "استأجر سيارتك بسهولة وبأفضل الأسعار",
  hero_subtitle:
    "تجربة قيادة مريحة وموثوقة. اختر سيارتك وأرسل طلب الحجز.",
  hero_image: "",
  whatsapp: "212600000000",
  city: "المغرب",
  accent: "#d4af37",
  logo_url: "",
  contact_phone: "",
  contact_email: "",
  address: "",
  instagram_url: "",
  facebook_url: "",
});

export const BACKUP_TABLES = [
  "site_settings",
  "site_sections",
  "cars",
  "customers",
  "bookings",
  "payments",
  "expenses",
  "vehicle_loans",
  "loan_payments",
  "maintenance_records",
];

export function text(value = "") {
  return String(value ?? "").trim();
}

export function normalizePhone(value, fallback = "212600000000") {
  let digits = String(value ?? "").replace(/\D/g, "");
  if (!digits) return fallback;
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("0") && digits.length === 10) digits = "212" + digits.slice(1);
  return digits;
}

export function normalizeUrl(value = "") {
  const v = text(value);
  if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (v.startsWith("/")) return v;
  return "";
}

export function normalizeSettings(input = {}, base = DEFAULT_SETTINGS) {
  const out = { ...base };
  for (const key of SETTINGS_COLUMNS) {
    if (key === "whatsapp") out[key] = normalizePhone(input[key], base[key]);
    else if (["hero_image", "logo_url", "instagram_url", "facebook_url"].includes(key))
      out[key] = normalizeUrl(input[key]);
    else out[key] = text(input[key]) || base[key];
  }
  if (!/^#[0-9a-f]{6}$/i.test(out.accent)) out.accent = DEFAULT_SETTINGS.accent;
  if (out.brand.length > 120) out.brand = out.brand.slice(0, 120);
  return out;
}

export function verifySettings(saved, expected, fields = SETTINGS_COLUMNS) {
  const savedRow = normalizeSettings(saved);
  const expectedRow = normalizeSettings(expected);
  const mismatches = fields.filter((key) => text(savedRow[key]) !== text(expectedRow[key]));
  return { ok: mismatches.length === 0, mismatches, saved: savedRow };
}

export function bookingDays(startDate, endDate) {
  const start = new Date(`${startDate}T12:00:00`);
  const end = new Date(`${endDate}T12:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 0;
  return Math.max(0, Math.round((end - start) / 86400000));
}

export function buildBookingPricing(data = {}, cars = []) {
  const car = cars.find((c) => c.id === data.car_id) || {};
  const days = bookingDays(data.start_date, data.end_date);
  const dailyRate = Number(data.daily_rate ?? car.daily_rate ?? 0) || 0;
  const discount = Number(data.discount_amount || 0) || 0;
  const total = data.total_amount != null && data.total_amount !== ""
    ? Number(data.total_amount)
    : Math.max(0, days * dailyRate - discount);
  return {
    customer_id: data.customer_id || data.customerId || "",
    car_id: data.car_id || data.carId || "",
    start_date: data.start_date,
    end_date: data.end_date,
    daily_rate: dailyRate,
    discount_amount: discount,
    total_amount: total,
    paid_amount: Number(data.paid_amount || 0) || 0,
    deposit_amount: Number(data.deposit_amount || 0) || 0,
    status: data.status || "pending",
    notes: text(data.notes),
  };
}

export function monthKey(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function buildMonthlyFinancials(payments = [], expenses = [], months = 7) {
  const now = new Date();
  const labels = [];
  const keys = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = monthKey(d);
    keys.push(key);
    labels.push(
      d.toLocaleDateString("ar-MA", { month: "short" }) +
        " " +
        String(d.getFullYear()).slice(2),
    );
  }
  const revenue = Object.fromEntries(keys.map((key) => [key, 0]));
  const cost = Object.fromEntries(keys.map((key) => [key, 0]));
  for (const p of payments) {
    const key = String(p.payment_date || "").slice(0, 7);
    if (!(key in revenue)) continue;
    const amount = Number(p.amount || 0);
    if (p.direction === "refund") revenue[key] -= amount;
    else revenue[key] += amount;
  }
  for (const e of expenses) {
    const key = String(e.expense_date || "").slice(0, 7);
    if (!(key in cost)) continue;
    cost[key] += Number(e.amount || 0);
  }
  return labels.map((label, i) => ({
    label,
    revenue: Math.max(0, revenue[keys[i]]),
    cost: cost[keys[i]],
  }));
}

export function buildOperationalBackup(snapshot = {}, extra = {}) {
  const tables = {};
  for (const table of BACKUP_TABLES) {
    const rows = snapshot[table];
    tables[table] = Array.isArray(rows) ? rows : [];
  }
  return {
    app: "elite-drive",
    version: 1,
    schemaVersion: SCHEMA_VERSION,
    appVersion: APP_VERSION,
    exportedAt: new Date().toISOString(),
    includesStorageFiles: false,
    storageNote:
      "هذه النسخة تحتوي مراجع الملفات والروابط فقط ولا تحتوي الملفات الثنائية من Supabase Storage.",
    tables,
    ...extra,
  };
}

export function validateBackup(payload) {
  const errors = [];
  if (!payload || typeof payload !== "object") errors.push("الملف ليس كائن JSON صالحاً.");
  else {
    if (payload.app !== "elite-drive") errors.push("تطبيق النسخة الاحتياطية غير مطابق.");
    if (Number(payload.version) !== 1) errors.push("إصدار ملف النسخة غير مدعوم.");
    if (Number(payload.schemaVersion) !== SCHEMA_VERSION)
      errors.push(`إصدار المخطط المتوقع ${SCHEMA_VERSION} غير مطابق.`);
    if (!payload.tables || typeof payload.tables !== "object") {
      errors.push("لا يوجد قسم tables.");
    } else {
      for (const table of BACKUP_TABLES) {
        if (table in payload.tables && !Array.isArray(payload.tables[table]))
          errors.push(`جدول ${table} يجب أن يكون مصفوفة.`);
      }
    }
  }
  return { ok: errors.length === 0, errors };
}

export function safeFileName(name = "file") {
  const cleaned = String(name)
    .normalize("NFKC")
    .replace(/[^a-zA-Z0-9._-]/g, "-")
    .replace(/-+/g, "-");
  return cleaned || "file";
}

export function storagePublicUrl(client, bucket, path) {
  return client.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

export async function optimizeImage(file, options = {}) {
  const {
    maxWidth = 1920,
    maxHeight = 1200,
    quality = 0.84,
    maxBytes = 900 * 1024,
  } = options;
  if (!file || !String(file.type || "").startsWith("image/")) {
    throw new Error("اختر ملف صورة صالحاً.");
  }
  if (file.type === "image/svg+xml") return file;
  if (file.size > 8 * 1024 * 1024) throw new Error("حجم الصورة الأصلي يتجاوز 8 ميغابايت.");
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxWidth / bitmap.width, maxHeight / bitmap.height);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  const toBlob = (type, q) =>
    new Promise((resolve, reject) =>
      canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("تعذر معالجة الصورة."))), type, q),
    );
  let blob = await toBlob("image/webp", quality).catch(() => null);
  if (!blob || blob.type !== "image/webp") blob = await toBlob("image/jpeg", quality);
  let q = quality;
  while (blob.size > maxBytes && q > 0.45) {
    q -= 0.08;
    blob = await toBlob(blob.type === "image/webp" ? "image/webp" : "image/jpeg", q);
  }
  const ext = blob.type === "image/webp" ? "webp" : blob.type === "image/png" ? "png" : "jpg";
  return new File([blob], `${Date.now()}-${safeFileName(file.name).replace(/\.[^.]+$/, "")}.${ext}`, {
    type: blob.type,
  });
}

export async function uploadOptimizedSiteAsset(client, file, folder = "site-assets", options = {}) {
  if (!client) throw new Error("اتصال Supabase غير متاح.");
  const optimized = await optimizeImage(file, options);
  const path = `${folder}/${Date.now()}-${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}-${safeFileName(optimized.name)}`;
  const { error } = await client.storage.from("site-assets").upload(path, optimized, {
    cacheControl: "31536000",
    upsert: false,
    contentType: optimized.type,
  });
  if (error) throw error;
  return { path, url: storagePublicUrl(client, "site-assets", path), fileName: optimized.name };
}

export async function getSiteSettings(client) {
  const { data, error } = await client
    .from("site_settings")
    .select("*")
    .eq("id", 1)
    .single();
  if (error) throw error;
  return normalizeSettings(data);
}

export async function updateSiteSettings(client, values, userId = null) {
  const normalized = normalizeSettings(values);
  const row = {
    id: 1,
    ...normalized,
    updated_by: userId,
    updated_at: new Date().toISOString(),
  };
  const { error } = await client.from("site_settings").upsert(row);
  if (error) throw error;
  const saved = await getSiteSettings(client);
  const verified = verifySettings(saved, normalized);
  if (!verified.ok) {
    const err = new Error("فشل التحقق من الحقول بعد الحفظ: " + verified.mismatches.join(", "));
    err.mismatches = verified.mismatches;
    throw err;
  }
  return { saved, verified };
}

export async function getBrandLogos(client) {
  const { data, error } = await client
    .from("site_sections")
    .select("settings")
    .eq("section_key", "brand_logos")
    .maybeSingle();
  if (error) throw error;
  const logos = Array.isArray(data?.settings?.logos) ? data.settings.logos : [];
  return logos.filter((logo) => logo && (logo.url || logo.path));
}

export async function saveBrandLogos(client, logos) {
  const clean = logos.filter((logo) => logo && (logo.url || logo.path));
  const payload = {
    section_key: "brand_logos",
    title: "شعارات السيارات",
    is_visible: true,
    settings: { logos: clean },
    updated_at: new Date().toISOString(),
  };
  const { error } = await client.from("site_sections").upsert(payload, { onConflict: "section_key" });
  if (error) throw error;
  const saved = await getBrandLogos(client);
  if (saved.length !== clean.length) {
    throw new Error("تم الحفظ لكن عدد الشعارات المسترجعة لا يطابق المطلوب.");
  }
  return saved;
}

export async function recordAudit(client, action, entityTable, entityId = null, details = {}) {
  if (!client) return false;
  try {
    const { error } = await client.rpc("log_sensitive_change", {
      p_action: action,
      p_entity_table: entityTable,
      p_entity_id: null,
      p_actor: null,
      p_details: { entity_id: entityId, ...details },
    });
    if (error) {
      console.warn("Audit RPC unavailable", error.message);
      return false;
    }
    return true;
  } catch (error) {
    console.warn("Audit operation skipped", error);
    return false;
  }
}

export async function fetchBackupSnapshot(client) {
  const names = BACKUP_TABLES;
  const results = await Promise.all(
    names.map((table) => client.from(table).select("*").limit(5000)),
  );
  const tables = {};
  const errors = [];
  results.forEach(({ data, error }, index) => {
    const name = names[index];
    if (error) errors.push({ table: name, message: error.message });
    else tables[name] = data || [];
  });
  return { tables, errors };
}

export async function restoreBackupSnapshot(client, payload, { merge = true } = {}) {
  const validation = validateBackup(payload);
  if (!validation.ok) throw new Error(validation.errors.join(" "));
  const restored = {};
  const errors = [];
  for (const table of BACKUP_TABLES) {
    const rows = payload.tables[table];
    if (!Array.isArray(rows) || !rows.length) continue;
    const cleanRows = rows.map((row) => ({ ...row }));
    if (table === "site_settings") {
      for (const row of cleanRows) delete row.updated_by;
      if (cleanRows.some((row) => row.id !== 1)) {
        errors.push({ table, message: "تجاهل سجل إعدادات لا يحمل id=1." });
        continue;
      }
    }
    const { error } = await client.from(table).upsert(cleanRows);
    if (error) errors.push({ table, message: error.message });
    else restored[table] = cleanRows.length;
  }
  return { restored, errors, merge };
}
