-- Elite Drive production hardening and workflow migration
-- Apply once in Supabase SQL Editor. Safe to re-run: uses IF NOT EXISTS and DROP IF EXISTS where needed.
BEGIN;

-- Canonical application metadata.
CREATE TABLE IF NOT EXISTS public.schema_migrations (
  name text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.schema_migrations (name)
VALUES ('2026-10-22_elite_drive_platform_hardening')
ON CONFLICT (name) DO NOTHING;

-- Reusable role helpers. These intentionally keep authorization decisions in PostgreSQL.
CREATE OR REPLACE FUNCTION public.current_profile_role()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = true;
$$;

CREATE OR REPLACE FUNCTION public.has_role(required_roles text[])
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid()
      AND is_active = true
      AND role = ANY(required_roles)
  );
$$;

CREATE OR REPLACE FUNCTION public.has_higher_or_equal_role(target_profile_id uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller_role text;
  target_role text;
BEGIN
  caller_role := public.current_profile_role();
  target_role := (SELECT role FROM public.profiles WHERE id = target_profile_id);
  IF caller_role IS NULL OR target_role IS NULL THEN RETURN false; END IF;
  IF caller_role = 'owner' THEN RETURN true; END IF;
  IF target_role = 'owner' THEN RETURN false; END IF;
  IF caller_role = 'admin' AND target_role IN ('admin','manager','staff','accountant','viewer') THEN RETURN true; END IF;
  IF caller_role = 'manager' AND target_role IN ('staff','viewer') THEN RETURN true; END IF;
  RETURN false;
END;
$$;

REVOKE ALL ON FUNCTION public.current_profile_role() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.has_role(text[]) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.has_higher_or_equal_role(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.current_profile_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_higher_or_equal_role(uuid) TO authenticated;

-- Protect profiles: admins cannot silently alter or disable the owner account.
DROP POLICY IF EXISTS profiles_self_write ON public.profiles;
DROP POLICY IF EXISTS profiles_admin_write ON public.profiles;
CREATE POLICY profiles_self_update ON public.profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (
    id = auth.uid()
    AND is_active = true
    AND role = public.current_profile_role()
  );
CREATE POLICY profiles_admin_write ON public.profiles
  FOR ALL TO authenticated
  USING (public.has_higher_or_equal_role(id))
  WITH CHECK (public.has_higher_or_equal_role(id));

-- Atomic payment ledger. Client applications must not manually update paid_amount and insert payments separately.
CREATE OR REPLACE FUNCTION public.record_booking_payment(
  p_booking_id uuid,
  p_amount numeric,
  p_method text DEFAULT 'cash',
  p_reference text DEFAULT '',
  p_notes text DEFAULT '',
  p_payment_date date DEFAULT CURRENT_DATE
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment_id uuid := gen_random_uuid();
  v_remaining numeric;
BEGIN
  IF NOT public.has_role(ARRAY['owner','admin','manager','accountant']) THEN
    RAISE EXCEPTION 'صلاحية تسجيل الدفعات غير كافية';
  END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'مبلغ الدفعة يجب أن يكون أكبر من صفر';
  END IF;
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'الحجز غير موجود'; END IF;
  v_remaining := GREATEST(0, COALESCE(v_booking.total_amount, 0) - COALESCE(v_booking.paid_amount, 0));
  IF p_amount > v_remaining THEN
    RAISE EXCEPTION 'مبلغ الدفعة أكبر من المتبقي للحجز (% > %)', p_amount, v_remaining;
  END IF;
  INSERT INTO public.payments (
    id, booking_id, amount, method, reference, notes,
    payment_date, direction, received_by, created_at, updated_at
  ) VALUES (
    v_payment_id, p_booking_id, p_amount, COALESCE(p_method, 'cash'),
    COALESCE(p_reference, ''), COALESCE(p_notes, ''), COALESCE(p_payment_date, CURRENT_DATE),
    'income', auth.uid(), now(), now()
  );
  UPDATE public.bookings
  SET paid_amount = COALESCE(paid_amount, 0) + p_amount,
      updated_at = now()
  WHERE id = p_booking_id;
  PERFORM public.log_sensitive_change('payment.recorded', 'payments', v_payment_id, NULL, jsonb_build_object('booking_id', p_booking_id, 'amount', p_amount));
  RETURN v_payment_id;
END;
$$;
REVOKE ALL ON FUNCTION public.record_booking_payment(uuid,numeric,text,text,text,date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.record_booking_payment(uuid,numeric,text,text,text,date) TO authenticated;

-- Server-side audit trail. Client roles can read only according to RLS and cannot fabricate insert rows.
CREATE OR REPLACE FUNCTION public.log_sensitive_change(
  p_action text,
  p_entity_table text,
  p_entity_id uuid,
  p_actor uuid,
  p_details jsonb DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(ARRAY['owner','admin','manager','accountant']) THEN
    RAISE EXCEPTION 'صلاحية تسجيل العملية الحساسة غير كافية';
  END IF;
  INSERT INTO public.audit_logs (actor_id, action, entity_table, entity_id, details, created_at)
  VALUES (COALESCE(p_actor, auth.uid()), p_action, p_entity_table, p_entity_id, COALESCE(p_details, '{}'::jsonb), now());
END;
$$;

CREATE OR REPLACE FUNCTION public.log_sensitive_change_internal(
  p_action text,
  p_entity_table text,
  p_entity_id uuid,
  p_actor uuid,
  p_details jsonb DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.audit_logs (actor_id, action, entity_table, entity_id, details, created_at)
  VALUES (COALESCE(p_actor, auth.uid()), p_action, p_entity_table, p_entity_id, COALESCE(p_details, '{}'::jsonb), now());
END;
$$;
REVOKE ALL ON FUNCTION public.log_sensitive_change_internal(text,text,uuid,uuid,jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.log_sensitive_change(text,text,uuid,uuid,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.log_sensitive_change(text,text,uuid,uuid,jsonb) TO authenticated;

DROP POLICY IF EXISTS audit_insert ON public.audit_logs;
REVOKE INSERT, UPDATE, DELETE ON public.audit_logs FROM authenticated, anon;
CREATE OR REPLACE FUNCTION public.audit_row_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.log_sensitive_change_internal('record.created', TG_TABLE_NAME, NEW.id, NULL, to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    PERFORM public.log_sensitive_change_internal('record.updated', TG_TABLE_NAME, NEW.id, NULL, jsonb_build_object('old', to_jsonb(OLD), 'new', to_jsonb(NEW)));
    RETURN NEW;
  ELSE
    PERFORM public.log_sensitive_change_internal('record.deleted', TG_TABLE_NAME, OLD.id, NULL, to_jsonb(OLD));
    RETURN OLD;
  END IF;
END;
$$;

DO $$
DECLARE
  t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['cars','customers','bookings','payments','expenses','maintenance_records','vehicle_loans','loan_payments','site_settings','site_sections'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS audit_%I_changes ON public.%I', t, t);
    EXECUTE format('CREATE TRIGGER audit_%I_changes AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.audit_row_change()', t, t);
  END LOOP;
END $$;

-- Delete access for explicitly confirmed operational reset. Financial tables remain limited to trusted roles.
DROP POLICY IF EXISTS payments_delete ON public.payments;
CREATE POLICY payments_delete ON public.payments
  FOR DELETE TO authenticated
  USING (public.has_role(ARRAY['owner','admin','manager','accountant']));
DROP POLICY IF EXISTS loan_payments_delete ON public.loan_payments;
CREATE POLICY loan_payments_delete ON public.loan_payments
  FOR DELETE TO authenticated
  USING (public.has_role(ARRAY['owner','admin','manager','accountant']));

-- Updated timestamps for ledger tables that previously had no trigger registration.
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS set_payments_updated_at ON public.payments;
CREATE TRIGGER set_payments_updated_at BEFORE UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS set_loan_payments_updated_at ON public.loan_payments;
CREATE TRIGGER set_loan_payments_updated_at BEFORE UPDATE ON public.loan_payments FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS set_site_sections_updated_at ON public.site_sections;
CREATE TRIGGER set_site_sections_updated_at BEFORE UPDATE ON public.site_sections FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Search and reporting indexes.
CREATE INDEX IF NOT EXISTS idx_cars_status ON public.cars(status);
CREATE INDEX IF NOT EXISTS idx_cars_name ON public.cars USING gin (to_tsvector('simple', name));
CREATE INDEX IF NOT EXISTS idx_customers_phone ON public.customers(phone);
CREATE INDEX IF NOT EXISTS idx_customers_name ON public.customers USING gin (to_tsvector('simple', full_name));
CREATE INDEX IF NOT EXISTS idx_bookings_vehicle_dates ON public.bookings(car_id, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_bookings_customer ON public.bookings(customer_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status_dates ON public.bookings(status, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_payments_booking_date ON public.payments(booking_id, payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_direction_date ON public.payments(direction, payment_date);
CREATE INDEX IF NOT EXISTS idx_expenses_vehicle_date ON public.expenses(car_id, expense_date);
CREATE INDEX IF NOT EXISTS idx_maintenance_vehicle_status ON public.maintenance_records(car_id, status, next_due_date);

-- Storage buckets: public site assets, private operational media and financial documents.
INSERT INTO storage.buckets (id, name, public)
VALUES
  ('site-assets','site-assets',true),
  ('car-images','car-images',false),
  ('contracts','contracts',false),
  ('receipts','receipts',false)
ON CONFLICT (id) DO UPDATE SET public = EXCLUDED.public;

DROP POLICY IF EXISTS site_assets_public_read ON storage.objects;
CREATE POLICY site_assets_public_read ON storage.objects
  FOR SELECT TO public, anon, authenticated
  USING (bucket_id = 'site-assets');
DROP POLICY IF EXISTS site_assets_authenticated_insert ON storage.objects;
CREATE POLICY site_assets_authenticated_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'site-assets'
    AND public.has_role(ARRAY['owner','admin','manager','staff'])
  );
DROP POLICY IF EXISTS site_assets_authenticated_update ON storage.objects;
CREATE POLICY site_assets_authenticated_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'site-assets' AND public.has_role(ARRAY['owner','admin','manager','staff']))
  WITH CHECK (bucket_id = 'site-assets' AND public.has_role(ARRAY['owner','admin','manager','staff']));
DROP POLICY IF EXISTS site_assets_authenticated_delete ON storage.objects;
CREATE POLICY site_assets_authenticated_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'site-assets' AND public.has_role(ARRAY['owner','admin','manager','staff']));

DROP POLICY IF EXISTS car_images_select ON storage.objects;
CREATE POLICY car_images_select ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'car-images' AND public.has_role(ARRAY['owner','admin','manager','staff']));
DROP POLICY IF EXISTS car_images_insert ON storage.objects;
CREATE POLICY car_images_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'car-images' AND public.has_role(ARRAY['owner','admin','manager','staff']));
DROP POLICY IF EXISTS car_images_update ON storage.objects;
CREATE POLICY car_images_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'car-images' AND public.has_role(ARRAY['owner','admin','manager','staff']))
  WITH CHECK (bucket_id = 'car-images' AND public.has_role(ARRAY['owner','admin','manager','staff']));
DROP POLICY IF EXISTS car_images_delete ON storage.objects;
CREATE POLICY car_images_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'car-images' AND public.has_role(ARRAY['owner','admin','manager','staff']));

DROP POLICY IF EXISTS contracts_private_select ON storage.objects;
CREATE POLICY contracts_private_select ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'contracts' AND public.has_role(ARRAY['owner','admin','manager']));
DROP POLICY IF EXISTS contracts_private_insert ON storage.objects;
CREATE POLICY contracts_private_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'contracts' AND public.has_role(ARRAY['owner','admin','manager']));
DROP POLICY IF EXISTS contracts_private_update ON storage.objects;
CREATE POLICY contracts_private_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'contracts' AND public.has_role(ARRAY['owner','admin','manager']))
  WITH CHECK (bucket_id = 'contracts' AND public.has_role(ARRAY['owner','admin','manager']));
DROP POLICY IF EXISTS contracts_private_delete ON storage.objects;
CREATE POLICY contracts_private_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'contracts' AND public.has_role(ARRAY['owner','admin','manager']));

DROP POLICY IF EXISTS receipts_private_select ON storage.objects;
CREATE POLICY receipts_private_select ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'receipts' AND public.has_role(ARRAY['owner','admin','manager','accountant']));
DROP POLICY IF EXISTS receipts_private_insert ON storage.objects;
CREATE POLICY receipts_private_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'receipts' AND public.has_role(ARRAY['owner','admin','manager','accountant']));
DROP POLICY IF EXISTS receipts_private_update ON storage.objects;
CREATE POLICY receipts_private_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'receipts' AND public.has_role(ARRAY['owner','admin','manager','accountant']))
  WITH CHECK (bucket_id = 'receipts' AND public.has_role(ARRAY['owner','admin','manager','accountant']));
DROP POLICY IF EXISTS receipts_private_delete ON storage.objects;
CREATE POLICY receipts_private_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'receipts' AND public.has_role(ARRAY['owner','admin','manager','accountant']));

COMMIT;
