-- Elite Drive: reliable admin profile lookup after Supabase password authentication.
-- Run this once in Supabase SQL Editor as project owner.
-- The function only returns the role of the currently authenticated user.

create or replace function public.get_my_profile()
returns table (role text, is_active boolean)
language sql
stable
security definer
set search_path = public, auth
as $$
  select p.role, p.is_active
  from public.profiles p
  where p.id = auth.uid()
  limit 1;
$$;

revoke all on function public.get_my_profile() from public;
grant execute on function public.get_my_profile() to authenticated;
